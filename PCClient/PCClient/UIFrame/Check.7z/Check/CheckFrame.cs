﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Microsoft.Win32;
using Newtonsoft.Json;
using System.IO;
using PCClient.Helper;
using System.Net.Sockets;

using System.Threading;
using ColorimeterService.Service;
using ColorimeterService.Service.impl;
using ColorimeterDAO.WinDomain;
using System.Net;
using Sunny.UI;
using System.Windows.Forms;
using System.Security.Permissions;
using System.Runtime.InteropServices;


namespace PCClient.UIFrame.Check
{

    //设置可以调用的范围
    [ComVisible(true)]
    [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
    
    public partial class Checkframe : Form
    {
       
        
        
        //[PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
        // 色差仪控制模块接口
        ColorimeterControlService colorimeterService = null;
        // 生产信息模块接口
        StripProductionInformationService stripService = null;
        // 生产信息模块窗体实体类
        StripProductionInformationDomain domain = StripProductionInformationDomain.Instance;

        public WebBrowser full{get;set; }

        string fullchart = System.Environment.CurrentDirectory + "\\showEchart\\V1full_chart.html";
        string leftchart = System.Environment.CurrentDirectory + "\\showEchart\\test.html";
        string midchart = System.Environment.CurrentDirectory + "\\showEchart\\V1midchart.html";
        string rightchart = System.Environment.CurrentDirectory + "\\showEchart\\V1rightchart.html";

        string fullchart_larger = System.Environment.CurrentDirectory + "\\showEchart\\V1fullchart_Larger.html";
        string leftchart_larger = System.Environment.CurrentDirectory + "\\showEchart\\V1leftchart_Larger.html";
        string midchart_larger = System.Environment.CurrentDirectory + "\\showEchart\\V1midchart_Larger.html";
        string rightchart_larger = System.Environment.CurrentDirectory + "\\showEchart\\V1rightchart_Larger.html";


        string str4 = AppDomain.CurrentDomain.BaseDirectory;//获取基目录，它由程序集冲突解决程序用来探测程序集。 
        string str5 = Application.StartupPath;//获取启动了应用程序的可执行文件的路径，不包括可执行文件的名称。 
        string str6 = Application.ExecutablePath;//获取启动了应用程序的可执行文件的路径，包括可执行文件的名称。 
        string str7 = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;//获取或设置包含该应用程序的目录的名称。
       

        Echarts_demo.Echarts_helper echarts = new Echarts_demo.Echarts_helper();

        public Thread thr = null;
        
        public Checkframe()
        {
            InitializeComponent();     
            //调用浏览器兼容类
            new BrowerProblem().SetWebBrowserFeatures(10);
            this.wb_fullchart.Url = new Uri(fullchart);
            this.btn_Linked.Enabled = true;
            this.btn_Broken.Enabled = false;
           

            //Thread t2 = new Thread(new ParameterizedThreadStart(ShowMsg));//有参数的委托
            //t2.Start(10);
            // init 窗体实体类，跟控件绑定
            InitializeWinDomain();
            
        }
        private void InitializeWinDomain()
        {
            this.text_JuanPorduceTime.DataBindings.Add("Text", domain, "rollStartProductTime", false);
            this.text_JuanProduceEndtime.DataBindings.Add("Text", domain, "rollEndProductTime", false);
            this.text_JuanNum.DataBindings.Add("Text", domain, "rollNumber", false);
            this.text_JuanLength.DataBindings.Add("Text", domain, "length", false);
            this.text_JuanWidth.DataBindings.Add("Text", domain, "width", false);
            this.text_JuanThickness.DataBindings.Add("Text", domain, "thickness", false);

            this.text_LetPassDeviationValue_L.DataBindings.Add("Text", domain, "deltaL_std", false);
            this.text_LetPassDeviationValue_a.DataBindings.Add("Text", domain, "deltaA_std", false);
            this.text_LetPassDeviationValue_b.DataBindings.Add("Text", domain, "deltaB_std", false);
            this.text_LetPassValue_L.DataBindings.Add("Text", domain, "L_C", false);
            this.text_LetPassValue_a.DataBindings.Add("Text", domain, "a_C", false);
            this.text_LetPassValue_b.DataBindings.Add("Text", domain, "b_C", false);
            this.text_ColorCode.DataBindings.Add("Text", domain, "colorCode", false);

            this.text_DeviationValue_L.DataBindings.Add("Text", domain, "deltaL", false);
            this.text_DeviationValue_a.DataBindings.Add("Text", domain, "deltaA", false);
            this.text_DeviationValue_b.DataBindings.Add("Text", domain, "deltaB", false);
            this.text_StandardDeviation.DataBindings.Add("Text", domain, "deltaE", false);

            this.text_IfGood.DataBindings.Add("FillColor", domain, "fillColor", false);
            this.text_IfGood.DataBindings.Add("Text", domain, "fillText", false);

           
        }
        private delegate void updateUIStartDelegate(object sender, System.Timers.ElapsedEventArgs e);
        private void updateUIStart(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (this.InvokeRequired)
            {
                updateUIStartDelegate d = updateUIStart;
                this.Invoke(d, sender, e);
            }
            else
            {
                this.text_JuanPorduceTime.DataBindings[0].ReadValue();
                this.text_JuanProduceEndtime.DataBindings[0].ReadValue();
                this.text_JuanNum.DataBindings[0].ReadValue();
                this.text_JuanLength.DataBindings[0].ReadValue();
                this.text_JuanWidth.DataBindings[0].ReadValue();
                this.text_JuanThickness.DataBindings[0].ReadValue();

                this.text_LetPassDeviationValue_L.DataBindings[0].ReadValue();
                this.text_LetPassDeviationValue_a.DataBindings[0].ReadValue();
                this.text_LetPassDeviationValue_b.DataBindings[0].ReadValue();
                this.text_LetPassValue_L.DataBindings[0].ReadValue();
                this.text_LetPassValue_a.DataBindings[0].ReadValue();
                this.text_LetPassValue_b.DataBindings[0].ReadValue();
                this.text_ColorCode.DataBindings[0].ReadValue();

                this.text_DeviationValue_L.DataBindings[0].ReadValue();
                this.text_DeviationValue_a.DataBindings[0].ReadValue();
                this.text_DeviationValue_b.DataBindings[0].ReadValue();
                this.text_StandardDeviation.DataBindings[0].ReadValue();


                this.text_IfGood.DataBindings[0].ReadValue();
                this.text_IfGood.DataBindings[1].ReadValue();

                
                
            }
        }

        /// <summary>
        /// 监听domain,判断domain是否有值，进行持续访问
        /// </summary>
        private void monitorDomain()
        {

            Object[] objArray = new Object[5];
            objArray[0] = (Object)domain.deltaL;
            objArray[1] = (Object)domain.deltaA;
            objArray[2] = (Object)domain.deltaB;
            objArray[3] = (Object)domain.deltaE;
            objArray[4] = (Object)domain.length;
            
        }

      
        public void ShowMsg(String msg)
        {
            
            MessageBox.Show(msg);
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // thr = new Thread(new ThreadStart(getdata));
            //thr = new Thread(new ParameterizedThreadStart(getdata));
            //thr.Start(domain.deltaL);
           // InvkeMethod(domain.deltaL, domain.deltaA, domain.deltaB, domain.deltaE, domain.length);
            //Object[] objArray = new Object[5];
            //objArray[0] = (Object)domain.deltaL;
            //objArray[1] = (Object)domain.deltaA;
            //objArray[2] = (Object)domain.deltaB;
            //objArray[3] = (Object)domain.deltaE;
            //objArray[4] = (Object)domain.length;
            //wb_leftchart.Document.InvokeScript("loadInfo", objArray);

            //wb_leftchart.Document.InvokeScript("Run", new object[] { "CShareFunction" });
        }
        
        private void CheckFrame_Load(object sender, EventArgs e)
        {
            this.wb_leftchart.Url = new Uri(leftchart);
            wb_leftchart.ObjectForScripting = this;//具体公开的对象,这里可以公开自定义对象
                     
        }

        


        private void btn_Linked_Click_1(object sender, EventArgs e)
        {

            this.btn_Linked.Enabled = false;
            this.btn_Broken.Enabled = true;
            // IP and EndPoint
            IPAddress ipAddress = IPAddress.Parse(this.text_IP.Text.Trim());
            IPEndPoint endPoint = new IPEndPoint(ipAddress, int.Parse(this.text_Port.Text.Trim()));
            // new service
            stripService = new StripProductionInformationServiceImpl(
                ref this.text_CurrentValue_L,
                ref this.text_CurrentValue_a,
                ref this.text_CurrentValue_b,
                ref this.text_JuanBroadwise,
                ref this.wb_leftchart
                );

            //发送接收信号
            colorimeterService = new ColorimeterControlServiceImpl(
                ipAddress,
                endPoint,
                ref this.text_ReceptMessage,
                ref this.text_ReceptPackagLength,
                ref this.text_ReceptTime,
                ref this.btn_Linked,
                ref StripProductionInformationServiceImpl.sempore
                );

            // read400Plc thread start here
            Thread read400PlcThread = new Thread(stripService.read400Plc);
            read400PlcThread.Start();




            // 创建一个定时线程，定时 执行updateUIStart方法。
            System.Timers.Timer timer = new System.Timers.Timer(10);
            timer.Elapsed += updateUIStart;
            
            timer.Enabled = false;
            timer.Start();

            // 创建一个定时线程，定时 执行getdata方法。
            //System.Timers.Timer timer1 = new System.Timers.Timer(10);
            //timer1.Elapsed += getdata;

            //timer1.Enabled = false;
            //timer1.Start();
            
            //thr = new Thread(new ThreadStart(getdata));
            //thr.Start();
            
            try
            {
                // 连接服务(colorimeterService.connectServer)要在stripService获取当前LAB(stripService.getCurrentLAB)之前，
                // 否则，第一次连接无法得到LAB，
                // 因为ColorimeterControlServiceImpl.threadRecvDataFlag = false，不开启getCurrentLAB的线程

                // 色差仪连接服务器
                colorimeterService.connectServer();
                // 得到当前色差仪 l a b,
                // 计算并判断是否合格
                stripService.getCurrentLABAndJudge();

            }

            catch (Exception ex)
            {
                MessageBox.Show("无法连接服务器!" + ex.Message);
            }
        }

        /// <summary>
        /// [btn_Broken]断开连接的点击事件函数
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //My_Conbobox();
            
            switch (comboBox1.SelectedItem.ToString())
            {
                case "全":
                    this.panel_Chart_Content.Controls.Clear();
                    full = new WebBrowser();
                    
                    panel_fullchart.Visible = false;
                    //panel_leftchart.Visible = false;
                    panel_midchart.Visible = false;
                    panel_rightchart.Visible = false;

                    full.Width = panel_Chart_Content.Width;
                    full.Height = panel_Chart_Content.Height;
                    this.panel_Chart_Content.Controls.Add(full);//将子窗体载入panel

                    this.full.Url = new Uri(fullchart_larger); 
                    break;
                    
                case "左":
                    this.panel_Chart_Content.Controls.Clear();
                    full = new WebBrowser();
                    
                    panel_fullchart.Visible = false;
                    //panel_leftchart.Visible = false;
                    panel_midchart.Visible = false;
                    panel_rightchart.Visible = false;

                    full.Width = panel_Chart_Content.Width;
                    full.Height = panel_Chart_Content.Height;
                    this.panel_Chart_Content.Controls.Add(full);//将子窗体载入panel
                    
                    this.full.Url = new Uri(leftchart_larger);
                    //getdata();
                    break;
                case "中":
                    this.panel_Chart_Content.Controls.Clear();
                    full = new WebBrowser();
                    
                    panel_fullchart.Visible = false;
                    //panel_leftchart.Visible = false;
                    panel_midchart.Visible = false;
                    panel_rightchart.Visible = false;

                    full.Width = panel_Chart_Content.Width;
                    full.Height = panel_Chart_Content.Height;
                    this.panel_Chart_Content.Controls.Add(full);//将子窗体载入panel

                    this.full.Url = new Uri(midchart_larger); 
                    break;
                case "右":
                    this.panel_Chart_Content.Controls.Clear();
                    full = new WebBrowser();
                    
                    panel_fullchart.Visible = false;
                    //panel_leftchart.Visible = false;
                    panel_midchart.Visible = false;
                    panel_rightchart.Visible = false;

                    full.Width = panel_Chart_Content.Width;
                    full.Height = panel_Chart_Content.Height;
                    this.panel_Chart_Content.Controls.Add(full);//将子窗体载入panel

                    this.full.Url = new Uri(rightchart_larger); 
                    break;
                case "同时":
                    this.wb_fullchart.Url = new Uri(fullchart);
                    //this.wb_leftchart.Url = new Uri(leftchart);
                    //this.wb_middlechart.Url = new Uri(midchart);
                    //this.wb_rightchart.Url = new Uri(rightchart);    
                    panel_fullchart.Visible = true;
                    //panel_leftchart.Visible = true;
                    panel_midchart.Visible = true;
                    panel_rightchart.Visible = true;
                    break;
                    //new Checkframe().ShowDialog();
                    
                    //this.FormBorderStyle = FormBorderStyle.None; //隐藏子窗体边框（去除最小花，最大化，关闭等按钮）
                    //this.TopLevel = false;//指示子窗体非顶级窗体
                    //break;
                    


            }
            
        }


        //private void wb_leftchart_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        //{
        //    this.wb_leftchart.Url = new Uri(leftchart);
        //    wb_leftchart.ObjectForScripting = this;//具体公开的对象,这里可以公开自定义对象
        //}

       
        //,domain.deltaA, domain.deltaB,domain.deltaE,domain.length
        private void getdata(object arr_L)
        {

            if (wb_leftchart.Document != null)
            {
                //HtmlDocument doc = wb_leftchart.Document;
                //String str = doc.InvokeScript("load").ToString();

                Object[] objArray = new Object[1];
                objArray[0] = (Object)arr_L;
                //objArray[1] = (Object)arr_a;
                //objArray[2] = (Object)arr_b;
                //objArray[3] = (Object)arr_E;
                //objArray[4] = (Object)arr_changdu;
                wb_leftchart.Document.InvokeScript("loadInfo", objArray); 

            }   
           // string arr_L = domain.deltaL;
             
            
            

        }

        

        private void wb_fullchart_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            
        }

        private void btn_Broken_Click(object sender, EventArgs e)
        {
            this.btn_Linked.Enabled = true;
            this.btn_Broken.Enabled = false;
            this.text_IP.Enabled = true;
            this.text_Port.Enabled = true;
            // 关闭与色差仪的连接
            colorimeterService.closeConnection();
        }

        
        private void getColorStandardbtn()
        {
            
            foreach (Control ctl in this.panel_ColorStadard.Controls)
            {
                string name = ctl.Name;
                //btn_selfTest.Click += new EventHandler(btn_selfTest_Click);
                if (ctl.Name == "btn_selfTest")
                {

                }
                else if (ctl.Name == "btn_rengongInput")
                {

                }
                else if (ctl.Name == "btn_LIMSS")
                {

                }
            }
        }

        private void btn_selfTest_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("是否切换<自对比>模式？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                btn_LIMSS.FillColor = Color.LightGray;
                btn_rengongInput.FillColor = Color.LightGray;
                btn_selfTest.FillColor = Color.Green;

            }
            else
            {
                return;
            }
        }

        private void btn_rengongInput_Click(object sender, EventArgs e)
        {
            
            DialogResult dr = MessageBox.Show("是否切换<人工输入>模式？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                btn_LIMSS.FillColor = Color.LightGray;
                btn_selfTest.FillColor = Color.LightGray;
                btn_rengongInput.FillColor = Color.Green;
            }
            else
            {
                return;
            }
            
        }
        
       
        private void btn_LIMSS_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("是否切换<LIMS>模式？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                btn_selfTest.FillColor = Color.LightGray;
                btn_rengongInput.FillColor = Color.LightGray;
                btn_LIMSS.FillColor = Color.Green;
            }
            else
            {
                return;
            }
        }

        private void wb_leftchart_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                colorimeterService.sendData(Encoding.UTF8.GetBytes(this.text_SendMessage.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace);
            }
        }
        TestFormServer tfs = null;

        private void btn_linkLocal_Click(object sender, EventArgs e)
        {
            tfs = new TestFormServer();
            tfs.Show();
        }
        

       
        

       

        





        

        
        
        
       
        
    }
}
