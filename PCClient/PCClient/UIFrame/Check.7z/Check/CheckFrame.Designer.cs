﻿namespace PCClient.UIFrame.Check
{
    partial class Checkframe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label_GDB;
            this.pic_LLLPosition = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label_LongDistance = new Sunny.UI.UILabel();
            this.lable_Fixed = new Sunny.UI.UILabel();
            this.lable_ComeZero_PC_Complete = new Sunny.UI.UILabel();
            this.lable_ComeZero_PC = new Sunny.UI.UILabel();
            this.label_Recyle = new Sunny.UI.UILabel();
            this.lable_AutoModel = new Sunny.UI.UILabel();
            this.lable_SettingModel = new Sunny.UI.UILabel();
            this.lable_PointMoveModel = new Sunny.UI.UILabel();
            this.text_RightPosition = new Sunny.UI.UITextBox();
            this.text_leftPosition = new Sunny.UI.UITextBox();
            this.text_IfGood = new Sunny.UI.UITextBox();
            this.pic_RightPosition = new System.Windows.Forms.PictureBox();
            this.pic_Rightbar = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.text_JuanBroadwise = new Sunny.UI.UITextBox();
            this.text_JuanWidth = new Sunny.UI.UITextBox();
            this.text_SubJuanNum = new Sunny.UI.UITextBox();
            this.text_JuanProduceEndtime = new Sunny.UI.UITextBox();
            this.text_JuanThickness = new Sunny.UI.UITextBox();
            this.text_JuanLength = new Sunny.UI.UITextBox();
            this.text_JuanNum = new Sunny.UI.UITextBox();
            this.text_JuanPorduceTime = new Sunny.UI.UITextBox();
            this.text_StandardDeviation = new Sunny.UI.UITextBox();
            this.uiLabel34 = new Sunny.UI.UILabel();
            this.uiLabel28 = new Sunny.UI.UILabel();
            this.uiLabel29 = new Sunny.UI.UILabel();
            this.uiLabel30 = new Sunny.UI.UILabel();
            this.uiLabel31 = new Sunny.UI.UILabel();
            this.text_DeviationValue_b = new Sunny.UI.UITextBox();
            this.text_DeviationValue_a = new Sunny.UI.UITextBox();
            this.text_CurrentValue_b = new Sunny.UI.UITextBox();
            this.text_DeviationValue_L = new Sunny.UI.UITextBox();
            this.text_CurrentValue_a = new Sunny.UI.UITextBox();
            this.text_CurrentValue_L = new Sunny.UI.UITextBox();
            this.uiLabel32 = new Sunny.UI.UILabel();
            this.uiLabel33 = new Sunny.UI.UILabel();
            this.label_ServoRunning = new Sunny.UI.UILabel();
            this.label_Position = new Sunny.UI.UILabel();
            this.uiLabel23 = new Sunny.UI.UILabel();
            this.uiLabel22 = new Sunny.UI.UILabel();
            this.label_OpeningSub = new Sunny.UI.UILabel();
            this.label_OpeningPlus = new Sunny.UI.UILabel();
            this.label_DriveMove = new Sunny.UI.UILabel();
            this.label_OperateMove = new Sunny.UI.UILabel();
            this.text_LIMS_ColorCode = new Sunny.UI.UITextBox();
            this.text_LIMS_b = new Sunny.UI.UITextBox();
            this.uiLabel17 = new Sunny.UI.UILabel();
            this.text_LIMS_a = new Sunny.UI.UITextBox();
            this.uiLabel16 = new Sunny.UI.UILabel();
            this.text_LIMS_L = new Sunny.UI.UITextBox();
            this.uiLabel15 = new Sunny.UI.UILabel();
            this.uiLabel14 = new Sunny.UI.UILabel();
            this.uiLabel12 = new Sunny.UI.UILabel();
            this.uiLabel13 = new Sunny.UI.UILabel();
            this.uiLabel10 = new Sunny.UI.UILabel();
            this.uiLabel11 = new Sunny.UI.UILabel();
            this.text_LetPassDeviationValue_L = new Sunny.UI.UITextBox();
            this.uiLabel8 = new Sunny.UI.UILabel();
            this.uiLabel9 = new Sunny.UI.UILabel();
            this.text_DBRectify_b = new Sunny.UI.UITextBox();
            this.text_DBRectify_a = new Sunny.UI.UITextBox();
            this.label_GDB2 = new Sunny.UI.UILabel();
            this.text_DBRectify_L = new Sunny.UI.UITextBox();
            this.label_GDB1 = new Sunny.UI.UILabel();
            this.label_GDB3 = new Sunny.UI.UILabel();
            this.text_GDB1_ColorCode = new Sunny.UI.UITextBox();
            this.text_GDB1_b = new Sunny.UI.UITextBox();
            this.text_GDB2_ColorCode = new Sunny.UI.UITextBox();
            this.text_GDB1_a = new Sunny.UI.UITextBox();
            this.text_GDB2_b = new Sunny.UI.UITextBox();
            this.text_GDB1_L = new Sunny.UI.UITextBox();
            this.text_GDB3_ColorCode = new Sunny.UI.UITextBox();
            this.text_GDB2_a = new Sunny.UI.UITextBox();
            this.text_GDB2_L = new Sunny.UI.UITextBox();
            this.text_GDB3_a = new Sunny.UI.UITextBox();
            this.text_GDB3_L = new Sunny.UI.UITextBox();
            this.text_SelfCheck_ColorCode = new Sunny.UI.UITextBox();
            this.text_SelfCheck_b = new Sunny.UI.UITextBox();
            this.text_Manualinput_ColorCode = new Sunny.UI.UITextBox();
            this.text_SelfCheck_a = new Sunny.UI.UITextBox();
            this.text_SelfCheck_L = new Sunny.UI.UITextBox();
            this.text_Manualinput_a = new Sunny.UI.UITextBox();
            this.text_Manualinput_L = new Sunny.UI.UITextBox();
            this.label_DBRectify = new Sunny.UI.UILabel();
            this.label_GuoFengSuona = new System.Windows.Forms.Label();
            this.label_SelfCheckBlue = new System.Windows.Forms.Label();
            this.label_LocalModelYellow = new System.Windows.Forms.Label();
            this.label_StateGreen = new System.Windows.Forms.Label();
            this.label_Error = new System.Windows.Forms.Label();
            this.text_Dodgelength = new System.Windows.Forms.TextBox();
            this.label_Dodgelength = new System.Windows.Forms.Label();
            this.text_HanFeng5 = new System.Windows.Forms.TextBox();
            this.text_HanFeng6 = new System.Windows.Forms.TextBox();
            this.btn_HanFeng5 = new System.Windows.Forms.Label();
            this.btn_HanFeng6 = new System.Windows.Forms.Label();
            this.text_ExportSpeed = new System.Windows.Forms.TextBox();
            this.label_ExportSpeed = new System.Windows.Forms.Label();
            this.text_TechnicSpeed = new System.Windows.Forms.TextBox();
            this.label_TechnicSpeed = new System.Windows.Forms.Label();
            this.btn_Center = new System.Windows.Forms.Button();
            this.btn_White = new System.Windows.Forms.Button();
            this.btn_Black = new System.Windows.Forms.Button();
            this.btn_Manualinput = new System.Windows.Forms.Button();
            this.btn_GDB1 = new System.Windows.Forms.Button();
            this.btn_GDB2 = new System.Windows.Forms.Button();
            this.btn_GDB3 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.text_UpthrowTime = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.text_InformationCue = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_WhiteCheck = new System.Windows.Forms.Button();
            this.btn_LongdistanceClosed = new System.Windows.Forms.Button();
            this.btn_StopSechayi = new System.Windows.Forms.Button();
            this.btn_BlackCheck = new System.Windows.Forms.Button();
            this.btn_LongdistanceOpen = new System.Windows.Forms.Button();
            this.btn_LinkedSechayi = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.btn_Broken = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label_DeviationValue = new System.Windows.Forms.Label();
            this.label_CurrentValue = new System.Windows.Forms.Label();
            this.label_ColorCode = new System.Windows.Forms.Label();
            this.label_JuanBroadwise = new System.Windows.Forms.Label();
            this.label_JuanThickness = new System.Windows.Forms.Label();
            this.label_JuanWidth = new System.Windows.Forms.Label();
            this.label_JuanLength = new System.Windows.Forms.Label();
            this.label_subJuanNum = new System.Windows.Forms.Label();
            this.label_JuanNum = new System.Windows.Forms.Label();
            this.label_Juan_Producton_EndTime = new System.Windows.Forms.Label();
            this.label_JuanPorduceTime = new System.Windows.Forms.Label();
            this.btn_Linked = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.uiLabel38 = new Sunny.UI.UILabel();
            this.panel_Chart_Content = new System.Windows.Forms.Panel();
            this.wb_leftchart = new System.Windows.Forms.WebBrowser();
            this.panel_rightchart = new System.Windows.Forms.Panel();
            this.wb_rightchart = new System.Windows.Forms.WebBrowser();
            this.panel_midchart = new System.Windows.Forms.Panel();
            this.wb_middlechart = new System.Windows.Forms.WebBrowser();
            this.panel_fullchart = new System.Windows.Forms.Panel();
            this.wb_fullchart = new System.Windows.Forms.WebBrowser();
            this.panel_LIMS = new System.Windows.Forms.Panel();
            this.uiLabel18 = new Sunny.UI.UILabel();
            this.uiTextBox11 = new Sunny.UI.UITextBox();
            this.uiTextBox2 = new Sunny.UI.UITextBox();
            this.btn_LIMSS = new Sunny.UI.UIButton();
            this.uiTextBox4 = new Sunny.UI.UITextBox();
            this.uiTextBox5 = new Sunny.UI.UITextBox();
            this.btn_selfTest = new Sunny.UI.UIButton();
            this.uiTextBox6 = new Sunny.UI.UITextBox();
            this.uiTextBox7 = new Sunny.UI.UITextBox();
            this.uiTextBox8 = new Sunny.UI.UITextBox();
            this.uiTextBox3 = new Sunny.UI.UITextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.uiTextBox15 = new Sunny.UI.UITextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.uiLabel21 = new Sunny.UI.UILabel();
            this.uiLabel20 = new Sunny.UI.UILabel();
            this.uiTextBox14 = new Sunny.UI.UITextBox();
            this.uiLabel19 = new Sunny.UI.UILabel();
            this.uiLabel4 = new Sunny.UI.UILabel();
            this.uiLabel5 = new Sunny.UI.UILabel();
            this.uiLabel6 = new Sunny.UI.UILabel();
            this.uiLabel7 = new Sunny.UI.UILabel();
            this.uiTextBox9 = new Sunny.UI.UITextBox();
            this.panel_ColorStadard = new System.Windows.Forms.Panel();
            this.btn_rengongInput = new Sunny.UI.UIButton();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.text_LetPassDeviationValue_b = new Sunny.UI.UITextBox();
            this.text_LetPassDeviationValue_a = new Sunny.UI.UITextBox();
            this.uiTextBox12 = new Sunny.UI.UITextBox();
            this.uiTextBox10 = new Sunny.UI.UITextBox();
            this.text_LetPassValue_b = new Sunny.UI.UITextBox();
            this.text_LetPassValue_a = new Sunny.UI.UITextBox();
            this.text_LetPassValue_L = new Sunny.UI.UITextBox();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.text_Manualinput_b = new Sunny.UI.UITextBox();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.text_GDB3_b = new Sunny.UI.UITextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_linkLocal = new Sunny.UI.UIButton();
            this.uiButton1 = new Sunny.UI.UIButton();
            this.uiTextBox49 = new Sunny.UI.UITextBox();
            this.uiTextBox48 = new Sunny.UI.UITextBox();
            this.uiTextBox45 = new Sunny.UI.UITextBox();
            this.uiTextBox44 = new Sunny.UI.UITextBox();
            this.uiTextBox41 = new Sunny.UI.UITextBox();
            this.uiTextBox40 = new Sunny.UI.UITextBox();
            this.uiTextBox47 = new Sunny.UI.UITextBox();
            this.uiTextBox34 = new Sunny.UI.UITextBox();
            this.uiTextBox43 = new Sunny.UI.UITextBox();
            this.uiTextBox35 = new Sunny.UI.UITextBox();
            this.uiTextBox39 = new Sunny.UI.UITextBox();
            this.uiTextBox46 = new Sunny.UI.UITextBox();
            this.text_ColorCode = new Sunny.UI.UITextBox();
            this.uiTextBox42 = new Sunny.UI.UITextBox();
            this.uiTextBox36 = new Sunny.UI.UITextBox();
            this.uiTextBox38 = new Sunny.UI.UITextBox();
            this.Text_NotCheckNum = new Sunny.UI.UITextBox();
            this.uiTextBox37 = new Sunny.UI.UITextBox();
            this.Text_NotGoodNum = new Sunny.UI.UITextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Text_CheckNum = new Sunny.UI.UITextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel_sechayiControl = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.text_SendMessage = new Sunny.UI.UITextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel_sechayiOpera = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.text_Port = new System.Windows.Forms.TextBox();
            this.text_IP = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.text_ReceptMessage = new Sunny.UI.UIRichTextBox();
            this.text_ReceptPackagLength = new Sunny.UI.UITextBox();
            this.text_ReceptTime = new Sunny.UI.UITextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.uiLabel24 = new Sunny.UI.UILabel();
            this.uiLabel25 = new Sunny.UI.UILabel();
            label_GDB = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pic_LLLPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_RightPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Rightbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel_Chart_Content.SuspendLayout();
            this.panel_rightchart.SuspendLayout();
            this.panel_midchart.SuspendLayout();
            this.panel_fullchart.SuspendLayout();
            this.panel_LIMS.SuspendLayout();
            this.panel_ColorStadard.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel_sechayiControl.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel_sechayiOpera.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_GDB
            // 
            label_GDB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            label_GDB.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            label_GDB.Location = new System.Drawing.Point(33, 146);
            label_GDB.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label_GDB.Name = "label_GDB";
            label_GDB.Size = new System.Drawing.Size(31, 104);
            label_GDB.TabIndex = 499;
            label_GDB.Text = "2标样板";
            label_GDB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pic_LLLPosition
            // 
            this.pic_LLLPosition.BackColor = System.Drawing.Color.Aquamarine;
            this.pic_LLLPosition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_LLLPosition.Location = new System.Drawing.Point(113, 192);
            this.pic_LLLPosition.Name = "pic_LLLPosition";
            this.pic_LLLPosition.Size = new System.Drawing.Size(23, 10);
            this.pic_LLLPosition.TabIndex = 643;
            this.pic_LLLPosition.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox8.Location = new System.Drawing.Point(119, 16);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(10, 238);
            this.pictureBox8.TabIndex = 642;
            this.pictureBox8.TabStop = false;
            // 
            // label_LongDistance
            // 
            this.label_LongDistance.BackColor = System.Drawing.Color.Lime;
            this.label_LongDistance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_LongDistance.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_LongDistance.Location = new System.Drawing.Point(5, 27);
            this.label_LongDistance.Name = "label_LongDistance";
            this.label_LongDistance.Size = new System.Drawing.Size(83, 28);
            this.label_LongDistance.TabIndex = 641;
            this.label_LongDistance.Text = "远控";
            this.label_LongDistance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lable_Fixed
            // 
            this.lable_Fixed.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lable_Fixed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lable_Fixed.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable_Fixed.Location = new System.Drawing.Point(175, 117);
            this.lable_Fixed.Name = "lable_Fixed";
            this.lable_Fixed.Size = new System.Drawing.Size(83, 30);
            this.lable_Fixed.TabIndex = 640;
            this.lable_Fixed.Text = "固定";
            this.lable_Fixed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lable_ComeZero_PC_Complete
            // 
            this.lable_ComeZero_PC_Complete.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lable_ComeZero_PC_Complete.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lable_ComeZero_PC_Complete.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable_ComeZero_PC_Complete.Location = new System.Drawing.Point(175, 57);
            this.lable_ComeZero_PC_Complete.Name = "lable_ComeZero_PC_Complete";
            this.lable_ComeZero_PC_Complete.Size = new System.Drawing.Size(83, 30);
            this.lable_ComeZero_PC_Complete.TabIndex = 639;
            this.lable_ComeZero_PC_Complete.Text = "回零完成";
            this.lable_ComeZero_PC_Complete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lable_ComeZero_PC
            // 
            this.lable_ComeZero_PC.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lable_ComeZero_PC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lable_ComeZero_PC.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable_ComeZero_PC.Location = new System.Drawing.Point(89, 57);
            this.lable_ComeZero_PC.Name = "lable_ComeZero_PC";
            this.lable_ComeZero_PC.Size = new System.Drawing.Size(83, 30);
            this.lable_ComeZero_PC.TabIndex = 638;
            this.lable_ComeZero_PC.Text = "回零_PC";
            this.lable_ComeZero_PC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Recyle
            // 
            this.label_Recyle.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_Recyle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_Recyle.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Recyle.Location = new System.Drawing.Point(89, 117);
            this.label_Recyle.Name = "label_Recyle";
            this.label_Recyle.Size = new System.Drawing.Size(83, 30);
            this.label_Recyle.TabIndex = 637;
            this.label_Recyle.Text = "循环";
            this.label_Recyle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lable_AutoModel
            // 
            this.lable_AutoModel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lable_AutoModel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lable_AutoModel.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable_AutoModel.Location = new System.Drawing.Point(5, 117);
            this.lable_AutoModel.Name = "lable_AutoModel";
            this.lable_AutoModel.Size = new System.Drawing.Size(83, 30);
            this.lable_AutoModel.TabIndex = 636;
            this.lable_AutoModel.Text = "自动模式";
            this.lable_AutoModel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lable_SettingModel
            // 
            this.lable_SettingModel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lable_SettingModel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lable_SettingModel.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable_SettingModel.Location = new System.Drawing.Point(5, 87);
            this.lable_SettingModel.Name = "lable_SettingModel";
            this.lable_SettingModel.Size = new System.Drawing.Size(83, 30);
            this.lable_SettingModel.TabIndex = 635;
            this.lable_SettingModel.Text = "手动设定模式";
            this.lable_SettingModel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lable_PointMoveModel
            // 
            this.lable_PointMoveModel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lable_PointMoveModel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lable_PointMoveModel.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable_PointMoveModel.Location = new System.Drawing.Point(5, 57);
            this.lable_PointMoveModel.Name = "lable_PointMoveModel";
            this.lable_PointMoveModel.Size = new System.Drawing.Size(83, 30);
            this.lable_PointMoveModel.TabIndex = 634;
            this.lable_PointMoveModel.Text = "手动点动模式";
            this.lable_PointMoveModel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // text_RightPosition
            // 
            this.text_RightPosition.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_RightPosition.DoubleValue = 150D;
            this.text_RightPosition.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.text_RightPosition.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_RightPosition.IntValue = 150;
            this.text_RightPosition.Location = new System.Drawing.Point(140, 262);
            this.text_RightPosition.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_RightPosition.Maximum = 2147483647D;
            this.text_RightPosition.Minimum = -2147483648D;
            this.text_RightPosition.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_RightPosition.Name = "text_RightPosition";
            this.text_RightPosition.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_RightPosition.RectColor = System.Drawing.Color.Black;
            this.text_RightPosition.Size = new System.Drawing.Size(37, 23);
            this.text_RightPosition.Style = Sunny.UI.UIStyle.Custom;
            this.text_RightPosition.TabIndex = 598;
            this.text_RightPosition.Text = "150";
            // 
            // text_leftPosition
            // 
            this.text_leftPosition.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_leftPosition.DoubleValue = 150D;
            this.text_leftPosition.FillColor = System.Drawing.Color.Aquamarine;
            this.text_leftPosition.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_leftPosition.IntValue = 150;
            this.text_leftPosition.Location = new System.Drawing.Point(104, 262);
            this.text_leftPosition.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_leftPosition.Maximum = 2147483647D;
            this.text_leftPosition.Minimum = -2147483648D;
            this.text_leftPosition.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_leftPosition.Name = "text_leftPosition";
            this.text_leftPosition.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_leftPosition.RectColor = System.Drawing.Color.Black;
            this.text_leftPosition.Size = new System.Drawing.Size(37, 23);
            this.text_leftPosition.Style = Sunny.UI.UIStyle.Custom;
            this.text_leftPosition.TabIndex = 597;
            this.text_leftPosition.Text = "150";
            // 
            // text_IfGood
            // 
            this.text_IfGood.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_IfGood.FillColor = System.Drawing.Color.Green;
            this.text_IfGood.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.text_IfGood.ForeColor = System.Drawing.Color.White;
            this.text_IfGood.Location = new System.Drawing.Point(388, 222);
            this.text_IfGood.Margin = new System.Windows.Forms.Padding(0);
            this.text_IfGood.Maximum = 2147483647D;
            this.text_IfGood.Minimum = -2147483648D;
            this.text_IfGood.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_IfGood.Name = "text_IfGood";
            this.text_IfGood.Padding = new System.Windows.Forms.Padding(3);
            this.text_IfGood.Size = new System.Drawing.Size(88, 29);
            this.text_IfGood.Style = Sunny.UI.UIStyle.Custom;
            this.text_IfGood.TabIndex = 613;
            this.text_IfGood.Text = "合格";
            this.text_IfGood.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pic_RightPosition
            // 
            this.pic_RightPosition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.pic_RightPosition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_RightPosition.Location = new System.Drawing.Point(149, 16);
            this.pic_RightPosition.Name = "pic_RightPosition";
            this.pic_RightPosition.Size = new System.Drawing.Size(23, 10);
            this.pic_RightPosition.TabIndex = 633;
            this.pic_RightPosition.TabStop = false;
            // 
            // pic_Rightbar
            // 
            this.pic_Rightbar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic_Rightbar.Location = new System.Drawing.Point(154, 16);
            this.pic_Rightbar.Name = "pic_Rightbar";
            this.pic_Rightbar.Size = new System.Drawing.Size(10, 238);
            this.pic_Rightbar.TabIndex = 632;
            this.pic_Rightbar.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox9.Location = new System.Drawing.Point(104, 5);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(37, 270);
            this.pictureBox9.TabIndex = 628;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(140, 5);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(37, 270);
            this.pictureBox7.TabIndex = 476;
            this.pictureBox7.TabStop = false;
            // 
            // text_JuanBroadwise
            // 
            this.text_JuanBroadwise.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_JuanBroadwise.FillColor = System.Drawing.Color.White;
            this.text_JuanBroadwise.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_JuanBroadwise.Location = new System.Drawing.Point(325, 153);
            this.text_JuanBroadwise.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_JuanBroadwise.Maximum = 2147483647D;
            this.text_JuanBroadwise.Minimum = -2147483648D;
            this.text_JuanBroadwise.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_JuanBroadwise.Name = "text_JuanBroadwise";
            this.text_JuanBroadwise.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_JuanBroadwise.RectColor = System.Drawing.Color.Black;
            this.text_JuanBroadwise.Size = new System.Drawing.Size(117, 26);
            this.text_JuanBroadwise.Style = Sunny.UI.UIStyle.Custom;
            this.text_JuanBroadwise.TabIndex = 626;
            // 
            // text_JuanWidth
            // 
            this.text_JuanWidth.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_JuanWidth.FillColor = System.Drawing.Color.White;
            this.text_JuanWidth.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_JuanWidth.Location = new System.Drawing.Point(325, 49);
            this.text_JuanWidth.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_JuanWidth.Maximum = 2147483647D;
            this.text_JuanWidth.Minimum = -2147483648D;
            this.text_JuanWidth.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_JuanWidth.Name = "text_JuanWidth";
            this.text_JuanWidth.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_JuanWidth.RectColor = System.Drawing.Color.Black;
            this.text_JuanWidth.Size = new System.Drawing.Size(117, 26);
            this.text_JuanWidth.Style = Sunny.UI.UIStyle.Custom;
            this.text_JuanWidth.TabIndex = 625;
            // 
            // text_SubJuanNum
            // 
            this.text_SubJuanNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_SubJuanNum.FillColor = System.Drawing.Color.White;
            this.text_SubJuanNum.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_SubJuanNum.Location = new System.Drawing.Point(325, 117);
            this.text_SubJuanNum.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_SubJuanNum.Maximum = 2147483647D;
            this.text_SubJuanNum.Minimum = -2147483648D;
            this.text_SubJuanNum.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_SubJuanNum.Name = "text_SubJuanNum";
            this.text_SubJuanNum.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_SubJuanNum.RectColor = System.Drawing.Color.Black;
            this.text_SubJuanNum.Size = new System.Drawing.Size(117, 26);
            this.text_SubJuanNum.Style = Sunny.UI.UIStyle.Custom;
            this.text_SubJuanNum.TabIndex = 627;
            // 
            // text_JuanProduceEndtime
            // 
            this.text_JuanProduceEndtime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_JuanProduceEndtime.FillColor = System.Drawing.Color.White;
            this.text_JuanProduceEndtime.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_JuanProduceEndtime.Location = new System.Drawing.Point(88, 83);
            this.text_JuanProduceEndtime.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_JuanProduceEndtime.Maximum = 2147483647D;
            this.text_JuanProduceEndtime.Minimum = -2147483648D;
            this.text_JuanProduceEndtime.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_JuanProduceEndtime.Name = "text_JuanProduceEndtime";
            this.text_JuanProduceEndtime.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_JuanProduceEndtime.RectColor = System.Drawing.Color.Black;
            this.text_JuanProduceEndtime.Size = new System.Drawing.Size(157, 26);
            this.text_JuanProduceEndtime.Style = Sunny.UI.UIStyle.Custom;
            this.text_JuanProduceEndtime.TabIndex = 624;
            // 
            // text_JuanThickness
            // 
            this.text_JuanThickness.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_JuanThickness.FillColor = System.Drawing.Color.White;
            this.text_JuanThickness.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_JuanThickness.Location = new System.Drawing.Point(325, 83);
            this.text_JuanThickness.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_JuanThickness.Maximum = 2147483647D;
            this.text_JuanThickness.Minimum = -2147483648D;
            this.text_JuanThickness.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_JuanThickness.Name = "text_JuanThickness";
            this.text_JuanThickness.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_JuanThickness.RectColor = System.Drawing.Color.Black;
            this.text_JuanThickness.Size = new System.Drawing.Size(117, 26);
            this.text_JuanThickness.Style = Sunny.UI.UIStyle.Custom;
            this.text_JuanThickness.TabIndex = 623;
            this.text_JuanThickness.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_JuanLength
            // 
            this.text_JuanLength.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_JuanLength.FillColor = System.Drawing.Color.White;
            this.text_JuanLength.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_JuanLength.Location = new System.Drawing.Point(88, 153);
            this.text_JuanLength.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_JuanLength.Maximum = 2147483647D;
            this.text_JuanLength.Minimum = -2147483648D;
            this.text_JuanLength.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_JuanLength.Name = "text_JuanLength";
            this.text_JuanLength.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_JuanLength.RectColor = System.Drawing.Color.Black;
            this.text_JuanLength.Size = new System.Drawing.Size(157, 26);
            this.text_JuanLength.Style = Sunny.UI.UIStyle.Custom;
            this.text_JuanLength.TabIndex = 622;
            this.text_JuanLength.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_JuanNum
            // 
            this.text_JuanNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_JuanNum.FillColor = System.Drawing.Color.White;
            this.text_JuanNum.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_JuanNum.Location = new System.Drawing.Point(88, 117);
            this.text_JuanNum.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_JuanNum.Maximum = 2147483647D;
            this.text_JuanNum.Minimum = -2147483648D;
            this.text_JuanNum.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_JuanNum.Name = "text_JuanNum";
            this.text_JuanNum.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_JuanNum.RectColor = System.Drawing.Color.Black;
            this.text_JuanNum.Size = new System.Drawing.Size(157, 26);
            this.text_JuanNum.Style = Sunny.UI.UIStyle.Custom;
            this.text_JuanNum.TabIndex = 621;
            this.text_JuanNum.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_JuanPorduceTime
            // 
            this.text_JuanPorduceTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_JuanPorduceTime.FillColor = System.Drawing.Color.White;
            this.text_JuanPorduceTime.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_JuanPorduceTime.Location = new System.Drawing.Point(88, 49);
            this.text_JuanPorduceTime.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_JuanPorduceTime.Maximum = 2147483647D;
            this.text_JuanPorduceTime.Minimum = -2147483648D;
            this.text_JuanPorduceTime.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_JuanPorduceTime.Name = "text_JuanPorduceTime";
            this.text_JuanPorduceTime.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_JuanPorduceTime.RectColor = System.Drawing.Color.Black;
            this.text_JuanPorduceTime.Size = new System.Drawing.Size(157, 26);
            this.text_JuanPorduceTime.Style = Sunny.UI.UIStyle.Custom;
            this.text_JuanPorduceTime.TabIndex = 620;
            this.text_JuanPorduceTime.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_StandardDeviation
            // 
            this.text_StandardDeviation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_StandardDeviation.FillColor = System.Drawing.Color.White;
            this.text_StandardDeviation.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_StandardDeviation.Location = new System.Drawing.Point(296, 243);
            this.text_StandardDeviation.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_StandardDeviation.Maximum = 2147483647D;
            this.text_StandardDeviation.Minimum = -2147483648D;
            this.text_StandardDeviation.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_StandardDeviation.Name = "text_StandardDeviation";
            this.text_StandardDeviation.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_StandardDeviation.RectColor = System.Drawing.Color.Black;
            this.text_StandardDeviation.Size = new System.Drawing.Size(70, 26);
            this.text_StandardDeviation.Style = Sunny.UI.UIStyle.Custom;
            this.text_StandardDeviation.TabIndex = 608;
            this.text_StandardDeviation.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiLabel34
            // 
            this.uiLabel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel34.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel34.Location = new System.Drawing.Point(296, 218);
            this.uiLabel34.Name = "uiLabel34";
            this.uiLabel34.Size = new System.Drawing.Size(70, 26);
            this.uiLabel34.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel34.TabIndex = 619;
            this.uiLabel34.Text = "∆E";
            this.uiLabel34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel28
            // 
            this.uiLabel28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiLabel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel28.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel28.Location = new System.Drawing.Point(228, 218);
            this.uiLabel28.Name = "uiLabel28";
            this.uiLabel28.Size = new System.Drawing.Size(70, 26);
            this.uiLabel28.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel28.TabIndex = 618;
            this.uiLabel28.Text = "b";
            this.uiLabel28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel29
            // 
            this.uiLabel29.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.uiLabel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel29.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel29.Location = new System.Drawing.Point(228, 269);
            this.uiLabel29.Name = "uiLabel29";
            this.uiLabel29.Size = new System.Drawing.Size(20, 26);
            this.uiLabel29.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel29.TabIndex = 617;
            this.uiLabel29.Text = "∆";
            this.uiLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel30
            // 
            this.uiLabel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.uiLabel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel30.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel30.Location = new System.Drawing.Point(158, 218);
            this.uiLabel30.Name = "uiLabel30";
            this.uiLabel30.Size = new System.Drawing.Size(70, 26);
            this.uiLabel30.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel30.TabIndex = 616;
            this.uiLabel30.Text = "a";
            this.uiLabel30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel31
            // 
            this.uiLabel31.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.uiLabel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel31.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel31.Location = new System.Drawing.Point(158, 269);
            this.uiLabel31.Name = "uiLabel31";
            this.uiLabel31.Size = new System.Drawing.Size(20, 26);
            this.uiLabel31.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel31.TabIndex = 615;
            this.uiLabel31.Text = "∆";
            this.uiLabel31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_DeviationValue_b
            // 
            this.text_DeviationValue_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_DeviationValue_b.FillColor = System.Drawing.Color.White;
            this.text_DeviationValue_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_DeviationValue_b.Location = new System.Drawing.Point(248, 269);
            this.text_DeviationValue_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_DeviationValue_b.Maximum = 2147483647D;
            this.text_DeviationValue_b.Minimum = -2147483648D;
            this.text_DeviationValue_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_DeviationValue_b.Name = "text_DeviationValue_b";
            this.text_DeviationValue_b.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_DeviationValue_b.RectColor = System.Drawing.Color.Black;
            this.text_DeviationValue_b.Size = new System.Drawing.Size(50, 26);
            this.text_DeviationValue_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_DeviationValue_b.TabIndex = 612;
            this.text_DeviationValue_b.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_DeviationValue_a
            // 
            this.text_DeviationValue_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_DeviationValue_a.FillColor = System.Drawing.Color.White;
            this.text_DeviationValue_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_DeviationValue_a.Location = new System.Drawing.Point(178, 269);
            this.text_DeviationValue_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_DeviationValue_a.Maximum = 2147483647D;
            this.text_DeviationValue_a.Minimum = -2147483648D;
            this.text_DeviationValue_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_DeviationValue_a.Name = "text_DeviationValue_a";
            this.text_DeviationValue_a.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_DeviationValue_a.RectColor = System.Drawing.Color.Black;
            this.text_DeviationValue_a.Size = new System.Drawing.Size(50, 26);
            this.text_DeviationValue_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_DeviationValue_a.TabIndex = 610;
            this.text_DeviationValue_a.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_CurrentValue_b
            // 
            this.text_CurrentValue_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_CurrentValue_b.FillColor = System.Drawing.Color.White;
            this.text_CurrentValue_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_CurrentValue_b.Location = new System.Drawing.Point(228, 243);
            this.text_CurrentValue_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_CurrentValue_b.Maximum = 2147483647D;
            this.text_CurrentValue_b.Minimum = -2147483648D;
            this.text_CurrentValue_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_CurrentValue_b.Name = "text_CurrentValue_b";
            this.text_CurrentValue_b.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_CurrentValue_b.RectColor = System.Drawing.Color.Black;
            this.text_CurrentValue_b.Size = new System.Drawing.Size(70, 26);
            this.text_CurrentValue_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_CurrentValue_b.TabIndex = 614;
            this.text_CurrentValue_b.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_DeviationValue_L
            // 
            this.text_DeviationValue_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_DeviationValue_L.FillColor = System.Drawing.Color.White;
            this.text_DeviationValue_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_DeviationValue_L.Location = new System.Drawing.Point(108, 269);
            this.text_DeviationValue_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_DeviationValue_L.Maximum = 2147483647D;
            this.text_DeviationValue_L.Minimum = -2147483648D;
            this.text_DeviationValue_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_DeviationValue_L.Name = "text_DeviationValue_L";
            this.text_DeviationValue_L.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_DeviationValue_L.RectColor = System.Drawing.Color.Black;
            this.text_DeviationValue_L.Size = new System.Drawing.Size(50, 26);
            this.text_DeviationValue_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_DeviationValue_L.TabIndex = 607;
            this.text_DeviationValue_L.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_CurrentValue_a
            // 
            this.text_CurrentValue_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_CurrentValue_a.FillColor = System.Drawing.Color.White;
            this.text_CurrentValue_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_CurrentValue_a.Location = new System.Drawing.Point(158, 243);
            this.text_CurrentValue_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_CurrentValue_a.Maximum = 2147483647D;
            this.text_CurrentValue_a.Minimum = -2147483648D;
            this.text_CurrentValue_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_CurrentValue_a.Name = "text_CurrentValue_a";
            this.text_CurrentValue_a.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_CurrentValue_a.RectColor = System.Drawing.Color.Black;
            this.text_CurrentValue_a.Size = new System.Drawing.Size(70, 26);
            this.text_CurrentValue_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_CurrentValue_a.TabIndex = 611;
            this.text_CurrentValue_a.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_CurrentValue_L
            // 
            this.text_CurrentValue_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_CurrentValue_L.FillColor = System.Drawing.Color.White;
            this.text_CurrentValue_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_CurrentValue_L.Location = new System.Drawing.Point(88, 243);
            this.text_CurrentValue_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_CurrentValue_L.Maximum = 2147483647D;
            this.text_CurrentValue_L.Minimum = -2147483648D;
            this.text_CurrentValue_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_CurrentValue_L.Name = "text_CurrentValue_L";
            this.text_CurrentValue_L.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_CurrentValue_L.RectColor = System.Drawing.Color.Black;
            this.text_CurrentValue_L.Size = new System.Drawing.Size(70, 26);
            this.text_CurrentValue_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_CurrentValue_L.TabIndex = 609;
            this.text_CurrentValue_L.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiLabel32
            // 
            this.uiLabel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel32.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel32.Location = new System.Drawing.Point(88, 218);
            this.uiLabel32.Name = "uiLabel32";
            this.uiLabel32.Size = new System.Drawing.Size(70, 26);
            this.uiLabel32.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel32.TabIndex = 606;
            this.uiLabel32.Text = "L";
            this.uiLabel32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel33
            // 
            this.uiLabel33.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.uiLabel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel33.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel33.Location = new System.Drawing.Point(88, 269);
            this.uiLabel33.Name = "uiLabel33";
            this.uiLabel33.Size = new System.Drawing.Size(20, 26);
            this.uiLabel33.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel33.TabIndex = 605;
            this.uiLabel33.Text = "∆";
            this.uiLabel33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_ServoRunning
            // 
            this.label_ServoRunning.BackColor = System.Drawing.Color.Silver;
            this.label_ServoRunning.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_ServoRunning.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label_ServoRunning.Location = new System.Drawing.Point(5, 160);
            this.label_ServoRunning.Name = "label_ServoRunning";
            this.label_ServoRunning.Padding = new System.Windows.Forms.Padding(3);
            this.label_ServoRunning.Size = new System.Drawing.Size(83, 27);
            this.label_ServoRunning.Style = Sunny.UI.UIStyle.Custom;
            this.label_ServoRunning.TabIndex = 604;
            this.label_ServoRunning.Text = "伺服运行";
            this.label_ServoRunning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Position
            // 
            this.label_Position.BackColor = System.Drawing.Color.Silver;
            this.label_Position.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_Position.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Position.Location = new System.Drawing.Point(29, 262);
            this.label_Position.Name = "label_Position";
            this.label_Position.Padding = new System.Windows.Forms.Padding(3);
            this.label_Position.Size = new System.Drawing.Size(75, 24);
            this.label_Position.Style = Sunny.UI.UIStyle.Custom;
            this.label_Position.TabIndex = 601;
            this.label_Position.Text = "位置(示例柱状图)";
            this.label_Position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel23
            // 
            this.uiLabel23.BackColor = System.Drawing.Color.White;
            this.uiLabel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel23.Location = new System.Drawing.Point(29, 66);
            this.uiLabel23.Name = "uiLabel23";
            this.uiLabel23.Padding = new System.Windows.Forms.Padding(3);
            this.uiLabel23.Size = new System.Drawing.Size(75, 28);
            this.uiLabel23.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel23.TabIndex = 602;
            this.uiLabel23.Text = "减速位";
            this.uiLabel23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel22
            // 
            this.uiLabel22.BackColor = System.Drawing.Color.Lime;
            this.uiLabel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel22.Location = new System.Drawing.Point(29, 39);
            this.uiLabel22.Name = "uiLabel22";
            this.uiLabel22.Padding = new System.Windows.Forms.Padding(3);
            this.uiLabel22.Size = new System.Drawing.Size(75, 28);
            this.uiLabel22.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel22.TabIndex = 600;
            this.uiLabel22.Text = "原位";
            this.uiLabel22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_OpeningSub
            // 
            this.label_OpeningSub.BackColor = System.Drawing.Color.Silver;
            this.label_OpeningSub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_OpeningSub.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_OpeningSub.Location = new System.Drawing.Point(29, 237);
            this.label_OpeningSub.Name = "label_OpeningSub";
            this.label_OpeningSub.Padding = new System.Windows.Forms.Padding(3);
            this.label_OpeningSub.Size = new System.Drawing.Size(75, 25);
            this.label_OpeningSub.Style = Sunny.UI.UIStyle.Custom;
            this.label_OpeningSub.TabIndex = 599;
            this.label_OpeningSub.Text = "极限开关-";
            this.label_OpeningSub.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_OpeningPlus
            // 
            this.label_OpeningPlus.BackColor = System.Drawing.Color.Silver;
            this.label_OpeningPlus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_OpeningPlus.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_OpeningPlus.Location = new System.Drawing.Point(29, 5);
            this.label_OpeningPlus.Name = "label_OpeningPlus";
            this.label_OpeningPlus.Padding = new System.Windows.Forms.Padding(3);
            this.label_OpeningPlus.Size = new System.Drawing.Size(75, 25);
            this.label_OpeningPlus.Style = Sunny.UI.UIStyle.Custom;
            this.label_OpeningPlus.TabIndex = 596;
            this.label_OpeningPlus.Text = "极限开关+";
            this.label_OpeningPlus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_DriveMove
            // 
            this.label_DriveMove.BackColor = System.Drawing.Color.Silver;
            this.label_DriveMove.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_DriveMove.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_DriveMove.Location = new System.Drawing.Point(176, 261);
            this.label_DriveMove.Name = "label_DriveMove";
            this.label_DriveMove.Padding = new System.Windows.Forms.Padding(3);
            this.label_DriveMove.Size = new System.Drawing.Size(89, 25);
            this.label_DriveMove.TabIndex = 595;
            this.label_DriveMove.Text = "传动侧移动";
            this.label_DriveMove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_OperateMove
            // 
            this.label_OperateMove.BackColor = System.Drawing.Color.Silver;
            this.label_OperateMove.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_OperateMove.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_OperateMove.Location = new System.Drawing.Point(177, 5);
            this.label_OperateMove.Name = "label_OperateMove";
            this.label_OperateMove.Padding = new System.Windows.Forms.Padding(3);
            this.label_OperateMove.Size = new System.Drawing.Size(88, 25);
            this.label_OperateMove.TabIndex = 594;
            this.label_OperateMove.Text = "操作侧移动";
            this.label_OperateMove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_LIMS_ColorCode
            // 
            this.text_LIMS_ColorCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LIMS_ColorCode.FillColor = System.Drawing.Color.White;
            this.text_LIMS_ColorCode.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LIMS_ColorCode.Location = new System.Drawing.Point(136, 79);
            this.text_LIMS_ColorCode.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LIMS_ColorCode.Maximum = 2147483647D;
            this.text_LIMS_ColorCode.Minimum = -2147483648D;
            this.text_LIMS_ColorCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LIMS_ColorCode.Name = "text_LIMS_ColorCode";
            this.text_LIMS_ColorCode.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LIMS_ColorCode.RectColor = System.Drawing.Color.Black;
            this.text_LIMS_ColorCode.Size = new System.Drawing.Size(84, 26);
            this.text_LIMS_ColorCode.Style = Sunny.UI.UIStyle.Custom;
            this.text_LIMS_ColorCode.TabIndex = 558;
            // 
            // text_LIMS_b
            // 
            this.text_LIMS_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LIMS_b.FillColor = System.Drawing.Color.White;
            this.text_LIMS_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LIMS_b.Location = new System.Drawing.Point(321, 79);
            this.text_LIMS_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LIMS_b.Maximum = 2147483647D;
            this.text_LIMS_b.Minimum = -2147483648D;
            this.text_LIMS_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LIMS_b.Name = "text_LIMS_b";
            this.text_LIMS_b.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LIMS_b.RectColor = System.Drawing.Color.Black;
            this.text_LIMS_b.Size = new System.Drawing.Size(51, 26);
            this.text_LIMS_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_LIMS_b.TabIndex = 562;
            // 
            // uiLabel17
            // 
            this.uiLabel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiLabel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel17.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel17.Location = new System.Drawing.Point(324, 95);
            this.uiLabel17.Name = "uiLabel17";
            this.uiLabel17.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel17.Size = new System.Drawing.Size(50, 24);
            this.uiLabel17.TabIndex = 592;
            this.uiLabel17.Text = "b*";
            this.uiLabel17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_LIMS_a
            // 
            this.text_LIMS_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LIMS_a.FillColor = System.Drawing.Color.White;
            this.text_LIMS_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LIMS_a.Location = new System.Drawing.Point(270, 79);
            this.text_LIMS_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LIMS_a.Maximum = 2147483647D;
            this.text_LIMS_a.Minimum = -2147483648D;
            this.text_LIMS_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LIMS_a.Name = "text_LIMS_a";
            this.text_LIMS_a.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LIMS_a.RectColor = System.Drawing.Color.Black;
            this.text_LIMS_a.Size = new System.Drawing.Size(50, 26);
            this.text_LIMS_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_LIMS_a.TabIndex = 559;
            // 
            // uiLabel16
            // 
            this.uiLabel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.uiLabel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel16.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel16.Location = new System.Drawing.Point(273, 95);
            this.uiLabel16.Name = "uiLabel16";
            this.uiLabel16.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel16.Size = new System.Drawing.Size(50, 24);
            this.uiLabel16.TabIndex = 591;
            this.uiLabel16.Text = "a*";
            this.uiLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_LIMS_L
            // 
            this.text_LIMS_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LIMS_L.FillColor = System.Drawing.Color.White;
            this.text_LIMS_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LIMS_L.Location = new System.Drawing.Point(220, 79);
            this.text_LIMS_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LIMS_L.Maximum = 2147483647D;
            this.text_LIMS_L.Minimum = -2147483648D;
            this.text_LIMS_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LIMS_L.Name = "text_LIMS_L";
            this.text_LIMS_L.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LIMS_L.RectColor = System.Drawing.Color.Black;
            this.text_LIMS_L.Size = new System.Drawing.Size(50, 26);
            this.text_LIMS_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_LIMS_L.TabIndex = 556;
            // 
            // uiLabel15
            // 
            this.uiLabel15.BackColor = System.Drawing.SystemColors.Control;
            this.uiLabel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel15.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel15.Location = new System.Drawing.Point(222, 95);
            this.uiLabel15.Name = "uiLabel15";
            this.uiLabel15.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel15.Size = new System.Drawing.Size(50, 24);
            this.uiLabel15.TabIndex = 590;
            this.uiLabel15.Text = "L*";
            this.uiLabel15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel14
            // 
            this.uiLabel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiLabel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel14.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel14.Location = new System.Drawing.Point(138, 95);
            this.uiLabel14.Name = "uiLabel14";
            this.uiLabel14.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel14.Size = new System.Drawing.Size(84, 24);
            this.uiLabel14.TabIndex = 589;
            this.uiLabel14.Text = "ColorCode";
            this.uiLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel12
            // 
            this.uiLabel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel12.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel12.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.uiLabel12.Location = new System.Drawing.Point(256, 29);
            this.uiLabel12.Name = "uiLabel12";
            this.uiLabel12.Size = new System.Drawing.Size(40, 26);
            this.uiLabel12.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel12.TabIndex = 588;
            this.uiLabel12.Text = "∆b*";
            this.uiLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel13
            // 
            this.uiLabel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiLabel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel13.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel13.Location = new System.Drawing.Point(256, 66);
            this.uiLabel13.Name = "uiLabel13";
            this.uiLabel13.Padding = new System.Windows.Forms.Padding(2);
            this.uiLabel13.Size = new System.Drawing.Size(40, 26);
            this.uiLabel13.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel13.TabIndex = 587;
            this.uiLabel13.Text = "b_C";
            this.uiLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiLabel10
            // 
            this.uiLabel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.uiLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel10.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel10.Location = new System.Drawing.Point(164, 29);
            this.uiLabel10.Name = "uiLabel10";
            this.uiLabel10.Size = new System.Drawing.Size(41, 26);
            this.uiLabel10.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel10.TabIndex = 586;
            this.uiLabel10.Text = "∆a*";
            this.uiLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiLabel11
            // 
            this.uiLabel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.uiLabel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel11.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel11.Location = new System.Drawing.Point(164, 66);
            this.uiLabel11.Name = "uiLabel11";
            this.uiLabel11.Padding = new System.Windows.Forms.Padding(2);
            this.uiLabel11.Size = new System.Drawing.Size(41, 26);
            this.uiLabel11.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel11.TabIndex = 585;
            this.uiLabel11.Text = "a_C";
            this.uiLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_LetPassDeviationValue_L
            // 
            this.text_LetPassDeviationValue_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LetPassDeviationValue_L.FillColor = System.Drawing.Color.White;
            this.text_LetPassDeviationValue_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LetPassDeviationValue_L.Location = new System.Drawing.Point(113, 29);
            this.text_LetPassDeviationValue_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LetPassDeviationValue_L.Maximum = 2147483647D;
            this.text_LetPassDeviationValue_L.Minimum = -2147483648D;
            this.text_LetPassDeviationValue_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LetPassDeviationValue_L.Name = "text_LetPassDeviationValue_L";
            this.text_LetPassDeviationValue_L.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LetPassDeviationValue_L.RectColor = System.Drawing.Color.Black;
            this.text_LetPassDeviationValue_L.Size = new System.Drawing.Size(50, 26);
            this.text_LetPassDeviationValue_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_LetPassDeviationValue_L.TabIndex = 580;
            // 
            // uiLabel8
            // 
            this.uiLabel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel8.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel8.Location = new System.Drawing.Point(72, 29);
            this.uiLabel8.Name = "uiLabel8";
            this.uiLabel8.Size = new System.Drawing.Size(41, 26);
            this.uiLabel8.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel8.TabIndex = 578;
            this.uiLabel8.Text = "∆L*";
            this.uiLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel9
            // 
            this.uiLabel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel9.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel9.Location = new System.Drawing.Point(72, 66);
            this.uiLabel9.Name = "uiLabel9";
            this.uiLabel9.Padding = new System.Windows.Forms.Padding(2);
            this.uiLabel9.Size = new System.Drawing.Size(41, 26);
            this.uiLabel9.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel9.TabIndex = 577;
            this.uiLabel9.Text = "L_C";
            this.uiLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_DBRectify_b
            // 
            this.text_DBRectify_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_DBRectify_b.FillColor = System.Drawing.Color.White;
            this.text_DBRectify_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_DBRectify_b.Location = new System.Drawing.Point(324, 224);
            this.text_DBRectify_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_DBRectify_b.Maximum = 2147483647D;
            this.text_DBRectify_b.Minimum = -2147483648D;
            this.text_DBRectify_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_DBRectify_b.Name = "text_DBRectify_b";
            this.text_DBRectify_b.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_DBRectify_b.RectColor = System.Drawing.Color.Black;
            this.text_DBRectify_b.Size = new System.Drawing.Size(50, 26);
            this.text_DBRectify_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_DBRectify_b.TabIndex = 575;
            // 
            // text_DBRectify_a
            // 
            this.text_DBRectify_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_DBRectify_a.FillColor = System.Drawing.Color.White;
            this.text_DBRectify_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_DBRectify_a.Location = new System.Drawing.Point(273, 224);
            this.text_DBRectify_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_DBRectify_a.Maximum = 2147483647D;
            this.text_DBRectify_a.Minimum = -2147483648D;
            this.text_DBRectify_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_DBRectify_a.Name = "text_DBRectify_a";
            this.text_DBRectify_a.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_DBRectify_a.RectColor = System.Drawing.Color.Black;
            this.text_DBRectify_a.Size = new System.Drawing.Size(50, 26);
            this.text_DBRectify_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_DBRectify_a.TabIndex = 573;
            // 
            // label_GDB2
            // 
            this.label_GDB2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_GDB2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_GDB2.Location = new System.Drawing.Point(63, 172);
            this.label_GDB2.Name = "label_GDB2";
            this.label_GDB2.Padding = new System.Windows.Forms.Padding(1);
            this.label_GDB2.Size = new System.Drawing.Size(74, 26);
            this.label_GDB2.TabIndex = 576;
            this.label_GDB2.Text = "-145标2";
            this.label_GDB2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_DBRectify_L
            // 
            this.text_DBRectify_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_DBRectify_L.FillColor = System.Drawing.Color.White;
            this.text_DBRectify_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_DBRectify_L.Location = new System.Drawing.Point(222, 224);
            this.text_DBRectify_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_DBRectify_L.Maximum = 2147483647D;
            this.text_DBRectify_L.Minimum = -2147483648D;
            this.text_DBRectify_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_DBRectify_L.Name = "text_DBRectify_L";
            this.text_DBRectify_L.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_DBRectify_L.RectColor = System.Drawing.Color.Black;
            this.text_DBRectify_L.Size = new System.Drawing.Size(50, 26);
            this.text_DBRectify_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_DBRectify_L.TabIndex = 571;
            // 
            // label_GDB1
            // 
            this.label_GDB1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_GDB1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_GDB1.Location = new System.Drawing.Point(63, 198);
            this.label_GDB1.Name = "label_GDB1";
            this.label_GDB1.Padding = new System.Windows.Forms.Padding(1);
            this.label_GDB1.Size = new System.Drawing.Size(74, 26);
            this.label_GDB1.TabIndex = 574;
            this.label_GDB1.Text = "-105标1";
            this.label_GDB1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_GDB3
            // 
            this.label_GDB3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_GDB3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_GDB3.Location = new System.Drawing.Point(63, 146);
            this.label_GDB3.Name = "label_GDB3";
            this.label_GDB3.Padding = new System.Windows.Forms.Padding(1);
            this.label_GDB3.Size = new System.Drawing.Size(74, 26);
            this.label_GDB3.TabIndex = 572;
            this.label_GDB3.Text = "-195标3";
            this.label_GDB3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_GDB1_ColorCode
            // 
            this.text_GDB1_ColorCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB1_ColorCode.FillColor = System.Drawing.Color.White;
            this.text_GDB1_ColorCode.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB1_ColorCode.Location = new System.Drawing.Point(137, 198);
            this.text_GDB1_ColorCode.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB1_ColorCode.Maximum = 2147483647D;
            this.text_GDB1_ColorCode.Minimum = -2147483648D;
            this.text_GDB1_ColorCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB1_ColorCode.Name = "text_GDB1_ColorCode";
            this.text_GDB1_ColorCode.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_GDB1_ColorCode.RectColor = System.Drawing.Color.Black;
            this.text_GDB1_ColorCode.Size = new System.Drawing.Size(84, 26);
            this.text_GDB1_ColorCode.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB1_ColorCode.TabIndex = 565;
            // 
            // text_GDB1_b
            // 
            this.text_GDB1_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB1_b.FillColor = System.Drawing.Color.White;
            this.text_GDB1_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB1_b.Location = new System.Drawing.Point(324, 198);
            this.text_GDB1_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB1_b.Maximum = 2147483647D;
            this.text_GDB1_b.Minimum = -2147483648D;
            this.text_GDB1_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB1_b.Name = "text_GDB1_b";
            this.text_GDB1_b.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB1_b.RectColor = System.Drawing.Color.Black;
            this.text_GDB1_b.Size = new System.Drawing.Size(50, 26);
            this.text_GDB1_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB1_b.TabIndex = 569;
            // 
            // text_GDB2_ColorCode
            // 
            this.text_GDB2_ColorCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB2_ColorCode.FillColor = System.Drawing.Color.White;
            this.text_GDB2_ColorCode.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB2_ColorCode.Location = new System.Drawing.Point(137, 172);
            this.text_GDB2_ColorCode.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB2_ColorCode.Maximum = 2147483647D;
            this.text_GDB2_ColorCode.Minimum = -2147483648D;
            this.text_GDB2_ColorCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB2_ColorCode.Name = "text_GDB2_ColorCode";
            this.text_GDB2_ColorCode.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_GDB2_ColorCode.RectColor = System.Drawing.Color.Black;
            this.text_GDB2_ColorCode.Size = new System.Drawing.Size(84, 26);
            this.text_GDB2_ColorCode.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB2_ColorCode.TabIndex = 566;
            // 
            // text_GDB1_a
            // 
            this.text_GDB1_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB1_a.FillColor = System.Drawing.Color.White;
            this.text_GDB1_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB1_a.Location = new System.Drawing.Point(273, 198);
            this.text_GDB1_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB1_a.Maximum = 2147483647D;
            this.text_GDB1_a.Minimum = -2147483648D;
            this.text_GDB1_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB1_a.Name = "text_GDB1_a";
            this.text_GDB1_a.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB1_a.RectColor = System.Drawing.Color.Black;
            this.text_GDB1_a.Size = new System.Drawing.Size(50, 26);
            this.text_GDB1_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB1_a.TabIndex = 567;
            // 
            // text_GDB2_b
            // 
            this.text_GDB2_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB2_b.FillColor = System.Drawing.Color.White;
            this.text_GDB2_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB2_b.Location = new System.Drawing.Point(324, 172);
            this.text_GDB2_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB2_b.Maximum = 2147483647D;
            this.text_GDB2_b.Minimum = -2147483648D;
            this.text_GDB2_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB2_b.Name = "text_GDB2_b";
            this.text_GDB2_b.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB2_b.RectColor = System.Drawing.Color.Black;
            this.text_GDB2_b.Size = new System.Drawing.Size(50, 26);
            this.text_GDB2_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB2_b.TabIndex = 570;
            // 
            // text_GDB1_L
            // 
            this.text_GDB1_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB1_L.FillColor = System.Drawing.Color.White;
            this.text_GDB1_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB1_L.Location = new System.Drawing.Point(222, 198);
            this.text_GDB1_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB1_L.Maximum = 2147483647D;
            this.text_GDB1_L.Minimum = -2147483648D;
            this.text_GDB1_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB1_L.Name = "text_GDB1_L";
            this.text_GDB1_L.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB1_L.RectColor = System.Drawing.Color.Black;
            this.text_GDB1_L.Size = new System.Drawing.Size(50, 26);
            this.text_GDB1_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB1_L.TabIndex = 563;
            // 
            // text_GDB3_ColorCode
            // 
            this.text_GDB3_ColorCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB3_ColorCode.FillColor = System.Drawing.Color.White;
            this.text_GDB3_ColorCode.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB3_ColorCode.Location = new System.Drawing.Point(137, 146);
            this.text_GDB3_ColorCode.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB3_ColorCode.Maximum = 2147483647D;
            this.text_GDB3_ColorCode.Minimum = -2147483648D;
            this.text_GDB3_ColorCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB3_ColorCode.Name = "text_GDB3_ColorCode";
            this.text_GDB3_ColorCode.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_GDB3_ColorCode.RectColor = System.Drawing.Color.Black;
            this.text_GDB3_ColorCode.Size = new System.Drawing.Size(84, 26);
            this.text_GDB3_ColorCode.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB3_ColorCode.TabIndex = 557;
            // 
            // text_GDB2_a
            // 
            this.text_GDB2_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB2_a.FillColor = System.Drawing.Color.White;
            this.text_GDB2_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB2_a.Location = new System.Drawing.Point(273, 172);
            this.text_GDB2_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB2_a.Maximum = 2147483647D;
            this.text_GDB2_a.Minimum = -2147483648D;
            this.text_GDB2_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB2_a.Name = "text_GDB2_a";
            this.text_GDB2_a.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB2_a.RectColor = System.Drawing.Color.Black;
            this.text_GDB2_a.Size = new System.Drawing.Size(50, 26);
            this.text_GDB2_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB2_a.TabIndex = 568;
            // 
            // text_GDB2_L
            // 
            this.text_GDB2_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB2_L.FillColor = System.Drawing.Color.White;
            this.text_GDB2_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB2_L.Location = new System.Drawing.Point(222, 172);
            this.text_GDB2_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB2_L.Maximum = 2147483647D;
            this.text_GDB2_L.Minimum = -2147483648D;
            this.text_GDB2_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB2_L.Name = "text_GDB2_L";
            this.text_GDB2_L.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB2_L.RectColor = System.Drawing.Color.Black;
            this.text_GDB2_L.Size = new System.Drawing.Size(50, 26);
            this.text_GDB2_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB2_L.TabIndex = 564;
            // 
            // text_GDB3_a
            // 
            this.text_GDB3_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB3_a.FillColor = System.Drawing.Color.White;
            this.text_GDB3_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB3_a.Location = new System.Drawing.Point(273, 146);
            this.text_GDB3_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB3_a.Maximum = 2147483647D;
            this.text_GDB3_a.Minimum = -2147483648D;
            this.text_GDB3_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB3_a.Name = "text_GDB3_a";
            this.text_GDB3_a.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB3_a.RectColor = System.Drawing.Color.Black;
            this.text_GDB3_a.Size = new System.Drawing.Size(50, 26);
            this.text_GDB3_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB3_a.TabIndex = 560;
            // 
            // text_GDB3_L
            // 
            this.text_GDB3_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB3_L.FillColor = System.Drawing.Color.White;
            this.text_GDB3_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB3_L.Location = new System.Drawing.Point(222, 146);
            this.text_GDB3_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB3_L.Maximum = 2147483647D;
            this.text_GDB3_L.Minimum = -2147483648D;
            this.text_GDB3_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB3_L.Name = "text_GDB3_L";
            this.text_GDB3_L.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB3_L.RectColor = System.Drawing.Color.Black;
            this.text_GDB3_L.Size = new System.Drawing.Size(50, 26);
            this.text_GDB3_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB3_L.TabIndex = 555;
            // 
            // text_SelfCheck_ColorCode
            // 
            this.text_SelfCheck_ColorCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_SelfCheck_ColorCode.FillColor = System.Drawing.Color.White;
            this.text_SelfCheck_ColorCode.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_SelfCheck_ColorCode.Location = new System.Drawing.Point(136, 4);
            this.text_SelfCheck_ColorCode.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_SelfCheck_ColorCode.Maximum = 2147483647D;
            this.text_SelfCheck_ColorCode.Minimum = -2147483648D;
            this.text_SelfCheck_ColorCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_SelfCheck_ColorCode.Name = "text_SelfCheck_ColorCode";
            this.text_SelfCheck_ColorCode.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_SelfCheck_ColorCode.RectColor = System.Drawing.Color.Black;
            this.text_SelfCheck_ColorCode.Size = new System.Drawing.Size(84, 26);
            this.text_SelfCheck_ColorCode.Style = Sunny.UI.UIStyle.Custom;
            this.text_SelfCheck_ColorCode.TabIndex = 552;
            // 
            // text_SelfCheck_b
            // 
            this.text_SelfCheck_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_SelfCheck_b.FillColor = System.Drawing.Color.White;
            this.text_SelfCheck_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_SelfCheck_b.Location = new System.Drawing.Point(321, 4);
            this.text_SelfCheck_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_SelfCheck_b.Maximum = 2147483647D;
            this.text_SelfCheck_b.Minimum = -2147483648D;
            this.text_SelfCheck_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_SelfCheck_b.Name = "text_SelfCheck_b";
            this.text_SelfCheck_b.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_SelfCheck_b.RectColor = System.Drawing.Color.Black;
            this.text_SelfCheck_b.Size = new System.Drawing.Size(50, 26);
            this.text_SelfCheck_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_SelfCheck_b.TabIndex = 554;
            // 
            // text_Manualinput_ColorCode
            // 
            this.text_Manualinput_ColorCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_Manualinput_ColorCode.FillColor = System.Drawing.Color.White;
            this.text_Manualinput_ColorCode.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_Manualinput_ColorCode.Location = new System.Drawing.Point(138, 120);
            this.text_Manualinput_ColorCode.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_Manualinput_ColorCode.Maximum = 2147483647D;
            this.text_Manualinput_ColorCode.Minimum = -2147483648D;
            this.text_Manualinput_ColorCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_Manualinput_ColorCode.Name = "text_Manualinput_ColorCode";
            this.text_Manualinput_ColorCode.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_Manualinput_ColorCode.RectColor = System.Drawing.Color.Black;
            this.text_Manualinput_ColorCode.Size = new System.Drawing.Size(84, 26);
            this.text_Manualinput_ColorCode.Style = Sunny.UI.UIStyle.Custom;
            this.text_Manualinput_ColorCode.TabIndex = 549;
            // 
            // text_SelfCheck_a
            // 
            this.text_SelfCheck_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_SelfCheck_a.FillColor = System.Drawing.Color.White;
            this.text_SelfCheck_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_SelfCheck_a.Location = new System.Drawing.Point(270, 4);
            this.text_SelfCheck_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_SelfCheck_a.Maximum = 2147483647D;
            this.text_SelfCheck_a.Minimum = -2147483648D;
            this.text_SelfCheck_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_SelfCheck_a.Name = "text_SelfCheck_a";
            this.text_SelfCheck_a.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_SelfCheck_a.RectColor = System.Drawing.Color.Black;
            this.text_SelfCheck_a.Size = new System.Drawing.Size(50, 26);
            this.text_SelfCheck_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_SelfCheck_a.TabIndex = 553;
            // 
            // text_SelfCheck_L
            // 
            this.text_SelfCheck_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_SelfCheck_L.FillColor = System.Drawing.Color.White;
            this.text_SelfCheck_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_SelfCheck_L.Location = new System.Drawing.Point(220, 4);
            this.text_SelfCheck_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_SelfCheck_L.Maximum = 2147483647D;
            this.text_SelfCheck_L.Minimum = -2147483648D;
            this.text_SelfCheck_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_SelfCheck_L.Name = "text_SelfCheck_L";
            this.text_SelfCheck_L.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_SelfCheck_L.RectColor = System.Drawing.Color.Black;
            this.text_SelfCheck_L.Size = new System.Drawing.Size(50, 26);
            this.text_SelfCheck_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_SelfCheck_L.TabIndex = 551;
            // 
            // text_Manualinput_a
            // 
            this.text_Manualinput_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_Manualinput_a.FillColor = System.Drawing.Color.White;
            this.text_Manualinput_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_Manualinput_a.Location = new System.Drawing.Point(274, 120);
            this.text_Manualinput_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_Manualinput_a.Maximum = 2147483647D;
            this.text_Manualinput_a.Minimum = -2147483648D;
            this.text_Manualinput_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_Manualinput_a.Name = "text_Manualinput_a";
            this.text_Manualinput_a.Padding = new System.Windows.Forms.Padding(5);
            this.text_Manualinput_a.RectColor = System.Drawing.Color.Black;
            this.text_Manualinput_a.Size = new System.Drawing.Size(50, 26);
            this.text_Manualinput_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_Manualinput_a.TabIndex = 548;
            // 
            // text_Manualinput_L
            // 
            this.text_Manualinput_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_Manualinput_L.FillColor = System.Drawing.Color.White;
            this.text_Manualinput_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_Manualinput_L.Location = new System.Drawing.Point(223, 120);
            this.text_Manualinput_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_Manualinput_L.Maximum = 2147483647D;
            this.text_Manualinput_L.Minimum = -2147483648D;
            this.text_Manualinput_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_Manualinput_L.Name = "text_Manualinput_L";
            this.text_Manualinput_L.Padding = new System.Windows.Forms.Padding(5);
            this.text_Manualinput_L.RectColor = System.Drawing.Color.Black;
            this.text_Manualinput_L.Size = new System.Drawing.Size(50, 26);
            this.text_Manualinput_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_Manualinput_L.TabIndex = 547;
            // 
            // label_DBRectify
            // 
            this.label_DBRectify.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_DBRectify.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label_DBRectify.Location = new System.Drawing.Point(64, 224);
            this.label_DBRectify.Name = "label_DBRectify";
            this.label_DBRectify.Size = new System.Drawing.Size(157, 26);
            this.label_DBRectify.TabIndex = 543;
            this.label_DBRectify.Text = "Lab数据库矫正";
            this.label_DBRectify.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_GuoFengSuona
            // 
            this.label_GuoFengSuona.AutoSize = true;
            this.label_GuoFengSuona.BackColor = System.Drawing.Color.Silver;
            this.label_GuoFengSuona.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_GuoFengSuona.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.label_GuoFengSuona.Location = new System.Drawing.Point(5, 220);
            this.label_GuoFengSuona.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_GuoFengSuona.Name = "label_GuoFengSuona";
            this.label_GuoFengSuona.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.label_GuoFengSuona.Size = new System.Drawing.Size(93, 26);
            this.label_GuoFengSuona.TabIndex = 542;
            this.label_GuoFengSuona.Text = "过焊缝报警喇叭";
            // 
            // label_SelfCheckBlue
            // 
            this.label_SelfCheckBlue.AutoSize = true;
            this.label_SelfCheckBlue.BackColor = System.Drawing.Color.Silver;
            this.label_SelfCheckBlue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_SelfCheckBlue.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.label_SelfCheckBlue.Location = new System.Drawing.Point(111, 190);
            this.label_SelfCheckBlue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_SelfCheckBlue.Name = "label_SelfCheckBlue";
            this.label_SelfCheckBlue.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.label_SelfCheckBlue.Size = new System.Drawing.Size(94, 26);
            this.label_SelfCheckBlue.TabIndex = 541;
            this.label_SelfCheckBlue.Text = "校验模式—蓝灯";
            // 
            // label_LocalModelYellow
            // 
            this.label_LocalModelYellow.AutoSize = true;
            this.label_LocalModelYellow.BackColor = System.Drawing.Color.Silver;
            this.label_LocalModelYellow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_LocalModelYellow.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.label_LocalModelYellow.Location = new System.Drawing.Point(112, 220);
            this.label_LocalModelYellow.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_LocalModelYellow.Name = "label_LocalModelYellow";
            this.label_LocalModelYellow.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.label_LocalModelYellow.Size = new System.Drawing.Size(94, 26);
            this.label_LocalModelYellow.TabIndex = 540;
            this.label_LocalModelYellow.Text = "就地模式—黄灯";
            // 
            // label_StateGreen
            // 
            this.label_StateGreen.AutoSize = true;
            this.label_StateGreen.BackColor = System.Drawing.Color.Silver;
            this.label_StateGreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_StateGreen.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.label_StateGreen.Location = new System.Drawing.Point(5, 190);
            this.label_StateGreen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_StateGreen.Name = "label_StateGreen";
            this.label_StateGreen.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.label_StateGreen.Size = new System.Drawing.Size(93, 26);
            this.label_StateGreen.TabIndex = 539;
            this.label_StateGreen.Text = "色差仪状态绿灯";
            // 
            // label_Error
            // 
            this.label_Error.AutoSize = true;
            this.label_Error.BackColor = System.Drawing.Color.Silver;
            this.label_Error.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_Error.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.label_Error.Location = new System.Drawing.Point(111, 160);
            this.label_Error.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Error.Name = "label_Error";
            this.label_Error.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.label_Error.Size = new System.Drawing.Size(40, 27);
            this.label_Error.TabIndex = 538;
            this.label_Error.Text = "故障";
            // 
            // text_Dodgelength
            // 
            this.text_Dodgelength.Location = new System.Drawing.Point(6, 103);
            this.text_Dodgelength.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_Dodgelength.Name = "text_Dodgelength";
            this.text_Dodgelength.Size = new System.Drawing.Size(61, 21);
            this.text_Dodgelength.TabIndex = 536;
            // 
            // label_Dodgelength
            // 
            this.label_Dodgelength.AutoSize = true;
            this.label_Dodgelength.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label_Dodgelength.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_Dodgelength.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Dodgelength.Location = new System.Drawing.Point(5, 71);
            this.label_Dodgelength.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Dodgelength.Name = "label_Dodgelength";
            this.label_Dodgelength.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.label_Dodgelength.Size = new System.Drawing.Size(61, 22);
            this.label_Dodgelength.TabIndex = 535;
            this.label_Dodgelength.Text = "避让长度";
            // 
            // text_HanFeng5
            // 
            this.text_HanFeng5.Location = new System.Drawing.Point(78, 39);
            this.text_HanFeng5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_HanFeng5.Name = "text_HanFeng5";
            this.text_HanFeng5.Size = new System.Drawing.Size(55, 21);
            this.text_HanFeng5.TabIndex = 534;
            // 
            // text_HanFeng6
            // 
            this.text_HanFeng6.Location = new System.Drawing.Point(5, 39);
            this.text_HanFeng6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_HanFeng6.Name = "text_HanFeng6";
            this.text_HanFeng6.Size = new System.Drawing.Size(55, 21);
            this.text_HanFeng6.TabIndex = 533;
            // 
            // btn_HanFeng5
            // 
            this.btn_HanFeng5.AutoSize = true;
            this.btn_HanFeng5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_HanFeng5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btn_HanFeng5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_HanFeng5.Location = new System.Drawing.Point(78, 8);
            this.btn_HanFeng5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btn_HanFeng5.Name = "btn_HanFeng5";
            this.btn_HanFeng5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_HanFeng5.Size = new System.Drawing.Size(55, 22);
            this.btn_HanFeng5.TabIndex = 532;
            this.btn_HanFeng5.Text = "过5焊缝";
            // 
            // btn_HanFeng6
            // 
            this.btn_HanFeng6.AutoSize = true;
            this.btn_HanFeng6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_HanFeng6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btn_HanFeng6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_HanFeng6.Location = new System.Drawing.Point(5, 8);
            this.btn_HanFeng6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btn_HanFeng6.Name = "btn_HanFeng6";
            this.btn_HanFeng6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_HanFeng6.Size = new System.Drawing.Size(55, 22);
            this.btn_HanFeng6.TabIndex = 531;
            this.btn_HanFeng6.Text = "过6焊缝";
            // 
            // text_ExportSpeed
            // 
            this.text_ExportSpeed.Location = new System.Drawing.Point(350, 44);
            this.text_ExportSpeed.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_ExportSpeed.Name = "text_ExportSpeed";
            this.text_ExportSpeed.Size = new System.Drawing.Size(56, 21);
            this.text_ExportSpeed.TabIndex = 530;
            // 
            // label_ExportSpeed
            // 
            this.label_ExportSpeed.AutoSize = true;
            this.label_ExportSpeed.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label_ExportSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_ExportSpeed.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_ExportSpeed.Location = new System.Drawing.Point(271, 42);
            this.label_ExportSpeed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ExportSpeed.Name = "label_ExportSpeed";
            this.label_ExportSpeed.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.label_ExportSpeed.Size = new System.Drawing.Size(76, 27);
            this.label_ExportSpeed.TabIndex = 529;
            this.label_ExportSpeed.Text = "出口段速度";
            // 
            // text_TechnicSpeed
            // 
            this.text_TechnicSpeed.Location = new System.Drawing.Point(350, 10);
            this.text_TechnicSpeed.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_TechnicSpeed.Name = "text_TechnicSpeed";
            this.text_TechnicSpeed.Size = new System.Drawing.Size(56, 21);
            this.text_TechnicSpeed.TabIndex = 528;
            // 
            // label_TechnicSpeed
            // 
            this.label_TechnicSpeed.AutoSize = true;
            this.label_TechnicSpeed.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label_TechnicSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_TechnicSpeed.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_TechnicSpeed.Location = new System.Drawing.Point(271, 6);
            this.label_TechnicSpeed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_TechnicSpeed.Name = "label_TechnicSpeed";
            this.label_TechnicSpeed.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.label_TechnicSpeed.Size = new System.Drawing.Size(76, 27);
            this.label_TechnicSpeed.TabIndex = 527;
            this.label_TechnicSpeed.Text = "工艺段速度";
            // 
            // btn_Center
            // 
            this.btn_Center.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_Center.Location = new System.Drawing.Point(176, 164);
            this.btn_Center.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Center.Name = "btn_Center";
            this.btn_Center.Size = new System.Drawing.Size(90, 25);
            this.btn_Center.TabIndex = 526;
            this.btn_Center.Text = "中心位1100";
            this.btn_Center.UseVisualStyleBackColor = true;
            // 
            // btn_White
            // 
            this.btn_White.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_White.Location = new System.Drawing.Point(176, 141);
            this.btn_White.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_White.Name = "btn_White";
            this.btn_White.Size = new System.Drawing.Size(90, 25);
            this.btn_White.TabIndex = 525;
            this.btn_White.Text = "白色";
            this.btn_White.UseVisualStyleBackColor = true;
            // 
            // btn_Black
            // 
            this.btn_Black.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_Black.Location = new System.Drawing.Point(176, 118);
            this.btn_Black.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Black.Name = "btn_Black";
            this.btn_Black.Size = new System.Drawing.Size(90, 25);
            this.btn_Black.TabIndex = 524;
            this.btn_Black.Text = "-34黑色";
            this.btn_Black.UseVisualStyleBackColor = true;
            // 
            // btn_Manualinput
            // 
            this.btn_Manualinput.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_Manualinput.Location = new System.Drawing.Point(176, 95);
            this.btn_Manualinput.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Manualinput.Name = "btn_Manualinput";
            this.btn_Manualinput.Size = new System.Drawing.Size(90, 25);
            this.btn_Manualinput.TabIndex = 523;
            this.btn_Manualinput.Text = "-150人工";
            this.btn_Manualinput.UseVisualStyleBackColor = true;
            // 
            // btn_GDB1
            // 
            this.btn_GDB1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_GDB1.Location = new System.Drawing.Point(176, 72);
            this.btn_GDB1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_GDB1.Name = "btn_GDB1";
            this.btn_GDB1.Size = new System.Drawing.Size(90, 25);
            this.btn_GDB1.TabIndex = 522;
            this.btn_GDB1.Text = "-105标1";
            this.btn_GDB1.UseVisualStyleBackColor = true;
            // 
            // btn_GDB2
            // 
            this.btn_GDB2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_GDB2.Location = new System.Drawing.Point(176, 49);
            this.btn_GDB2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_GDB2.Name = "btn_GDB2";
            this.btn_GDB2.Size = new System.Drawing.Size(90, 25);
            this.btn_GDB2.TabIndex = 521;
            this.btn_GDB2.Text = "-145标2";
            this.btn_GDB2.UseVisualStyleBackColor = true;
            // 
            // btn_GDB3
            // 
            this.btn_GDB3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_GDB3.Location = new System.Drawing.Point(176, 29);
            this.btn_GDB3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_GDB3.Name = "btn_GDB3";
            this.btn_GDB3.Size = new System.Drawing.Size(90, 25);
            this.btn_GDB3.TabIndex = 520;
            this.btn_GDB3.Text = "-195标3";
            this.btn_GDB3.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.textBox5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox5.Location = new System.Drawing.Point(29, 150);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(75, 23);
            this.textBox5.TabIndex = 519;
            this.textBox5.Text = "1545.00";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.Yellow;
            this.textBox4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4.Location = new System.Drawing.Point(29, 127);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(75, 23);
            this.textBox4.TabIndex = 518;
            this.textBox4.Text = "0.89";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.textBox3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox3.Location = new System.Drawing.Point(29, 104);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(75, 23);
            this.textBox3.TabIndex = 517;
            this.textBox3.Text = "655";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // text_UpthrowTime
            // 
            this.text_UpthrowTime.Location = new System.Drawing.Point(9, 70);
            this.text_UpthrowTime.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_UpthrowTime.Name = "text_UpthrowTime";
            this.text_UpthrowTime.Size = new System.Drawing.Size(174, 21);
            this.text_UpthrowTime.TabIndex = 516;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(2, 52);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 17);
            this.label4.TabIndex = 515;
            this.label4.Text = "上抛时刻";
            // 
            // text_InformationCue
            // 
            this.text_InformationCue.Location = new System.Drawing.Point(9, 24);
            this.text_InformationCue.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_InformationCue.Name = "text_InformationCue";
            this.text_InformationCue.Size = new System.Drawing.Size(174, 21);
            this.text_InformationCue.TabIndex = 514;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(2, 5);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 513;
            this.label3.Text = "信息提示";
            // 
            // btn_WhiteCheck
            // 
            this.btn_WhiteCheck.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_WhiteCheck.Location = new System.Drawing.Point(144, 59);
            this.btn_WhiteCheck.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_WhiteCheck.Name = "btn_WhiteCheck";
            this.btn_WhiteCheck.Size = new System.Drawing.Size(65, 26);
            this.btn_WhiteCheck.TabIndex = 511;
            this.btn_WhiteCheck.Text = "白校验";
            this.btn_WhiteCheck.UseVisualStyleBackColor = true;
            // 
            // btn_LongdistanceClosed
            // 
            this.btn_LongdistanceClosed.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_LongdistanceClosed.Location = new System.Drawing.Point(73, 60);
            this.btn_LongdistanceClosed.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_LongdistanceClosed.Name = "btn_LongdistanceClosed";
            this.btn_LongdistanceClosed.Size = new System.Drawing.Size(65, 26);
            this.btn_LongdistanceClosed.TabIndex = 510;
            this.btn_LongdistanceClosed.Text = "远程关闭";
            this.btn_LongdistanceClosed.UseVisualStyleBackColor = true;
            // 
            // btn_StopSechayi
            // 
            this.btn_StopSechayi.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_StopSechayi.Location = new System.Drawing.Point(4, 60);
            this.btn_StopSechayi.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_StopSechayi.Name = "btn_StopSechayi";
            this.btn_StopSechayi.Size = new System.Drawing.Size(65, 26);
            this.btn_StopSechayi.TabIndex = 509;
            this.btn_StopSechayi.Text = "停止";
            this.btn_StopSechayi.UseVisualStyleBackColor = true;
            // 
            // btn_BlackCheck
            // 
            this.btn_BlackCheck.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_BlackCheck.Location = new System.Drawing.Point(144, 28);
            this.btn_BlackCheck.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_BlackCheck.Name = "btn_BlackCheck";
            this.btn_BlackCheck.Size = new System.Drawing.Size(65, 26);
            this.btn_BlackCheck.TabIndex = 508;
            this.btn_BlackCheck.Text = "黑校验";
            this.btn_BlackCheck.UseVisualStyleBackColor = true;
            // 
            // btn_LongdistanceOpen
            // 
            this.btn_LongdistanceOpen.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_LongdistanceOpen.Location = new System.Drawing.Point(73, 28);
            this.btn_LongdistanceOpen.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_LongdistanceOpen.Name = "btn_LongdistanceOpen";
            this.btn_LongdistanceOpen.Size = new System.Drawing.Size(65, 26);
            this.btn_LongdistanceOpen.TabIndex = 507;
            this.btn_LongdistanceOpen.Text = "远程打开";
            this.btn_LongdistanceOpen.UseVisualStyleBackColor = true;
            // 
            // btn_LinkedSechayi
            // 
            this.btn_LinkedSechayi.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_LinkedSechayi.Location = new System.Drawing.Point(4, 28);
            this.btn_LinkedSechayi.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_LinkedSechayi.Name = "btn_LinkedSechayi";
            this.btn_LinkedSechayi.Size = new System.Drawing.Size(65, 26);
            this.btn_LinkedSechayi.TabIndex = 506;
            this.btn_LinkedSechayi.Text = "连接";
            this.btn_LinkedSechayi.UseVisualStyleBackColor = true;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label51.Location = new System.Drawing.Point(2, 0);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(121, 20);
            this.label51.TabIndex = 505;
            this.label51.Text = "色差仪机头操作板";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label50.Location = new System.Drawing.Point(2, 0);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(37, 20);
            this.label50.TabIndex = 503;
            this.label50.Text = "连接";
            // 
            // btn_Broken
            // 
            this.btn_Broken.Location = new System.Drawing.Point(186, 60);
            this.btn_Broken.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_Broken.Name = "btn_Broken";
            this.btn_Broken.Size = new System.Drawing.Size(60, 26);
            this.btn_Broken.TabIndex = 502;
            this.btn_Broken.Text = "断开";
            this.btn_Broken.UseVisualStyleBackColor = true;
            this.btn_Broken.Click += new System.EventHandler(this.btn_Broken_Click);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(2, 3);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(90, 22);
            this.label49.TabIndex = 500;
            this.label49.Text = "色差仪控制";
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(20, 39);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(47, 60);
            this.label35.TabIndex = 497;
            this.label35.Text = "放行标准";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(1, 2);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(74, 22);
            this.label25.TabIndex = 496;
            this.label25.Text = "颜色标准";
            // 
            // label_DeviationValue
            // 
            this.label_DeviationValue.AutoSize = true;
            this.label_DeviationValue.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_DeviationValue.Location = new System.Drawing.Point(30, 275);
            this.label_DeviationValue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_DeviationValue.Name = "label_DeviationValue";
            this.label_DeviationValue.Size = new System.Drawing.Size(51, 20);
            this.label_DeviationValue.TabIndex = 495;
            this.label_DeviationValue.Text = "偏差值";
            // 
            // label_CurrentValue
            // 
            this.label_CurrentValue.AutoSize = true;
            this.label_CurrentValue.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_CurrentValue.Location = new System.Drawing.Point(30, 245);
            this.label_CurrentValue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_CurrentValue.Name = "label_CurrentValue";
            this.label_CurrentValue.Size = new System.Drawing.Size(51, 20);
            this.label_CurrentValue.TabIndex = 494;
            this.label_CurrentValue.Text = "当前值";
            // 
            // label_ColorCode
            // 
            this.label_ColorCode.AutoSize = true;
            this.label_ColorCode.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_ColorCode.Location = new System.Drawing.Point(19, 189);
            this.label_ColorCode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_ColorCode.Name = "label_ColorCode";
            this.label_ColorCode.Size = new System.Drawing.Size(65, 20);
            this.label_ColorCode.TabIndex = 492;
            this.label_ColorCode.Text = "颜色代码";
            // 
            // label_JuanBroadwise
            // 
            this.label_JuanBroadwise.AutoSize = true;
            this.label_JuanBroadwise.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_JuanBroadwise.Location = new System.Drawing.Point(275, 158);
            this.label_JuanBroadwise.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_JuanBroadwise.Name = "label_JuanBroadwise";
            this.label_JuanBroadwise.Size = new System.Drawing.Size(37, 20);
            this.label_JuanBroadwise.TabIndex = 491;
            this.label_JuanBroadwise.Text = "横向";
            // 
            // label_JuanThickness
            // 
            this.label_JuanThickness.AutoSize = true;
            this.label_JuanThickness.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_JuanThickness.Location = new System.Drawing.Point(277, 85);
            this.label_JuanThickness.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_JuanThickness.Name = "label_JuanThickness";
            this.label_JuanThickness.Size = new System.Drawing.Size(37, 20);
            this.label_JuanThickness.TabIndex = 490;
            this.label_JuanThickness.Text = "厚度";
            // 
            // label_JuanWidth
            // 
            this.label_JuanWidth.AutoSize = true;
            this.label_JuanWidth.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_JuanWidth.Location = new System.Drawing.Point(277, 55);
            this.label_JuanWidth.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_JuanWidth.Name = "label_JuanWidth";
            this.label_JuanWidth.Size = new System.Drawing.Size(37, 20);
            this.label_JuanWidth.TabIndex = 489;
            this.label_JuanWidth.Text = "宽度";
            // 
            // label_JuanLength
            // 
            this.label_JuanLength.AutoSize = true;
            this.label_JuanLength.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_JuanLength.Location = new System.Drawing.Point(47, 158);
            this.label_JuanLength.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_JuanLength.Name = "label_JuanLength";
            this.label_JuanLength.Size = new System.Drawing.Size(37, 20);
            this.label_JuanLength.TabIndex = 488;
            this.label_JuanLength.Text = "长度";
            // 
            // label_subJuanNum
            // 
            this.label_subJuanNum.AutoSize = true;
            this.label_subJuanNum.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_subJuanNum.ForeColor = System.Drawing.Color.Blue;
            this.label_subJuanNum.Location = new System.Drawing.Point(263, 120);
            this.label_subJuanNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_subJuanNum.Name = "label_subJuanNum";
            this.label_subJuanNum.Size = new System.Drawing.Size(51, 20);
            this.label_subJuanNum.TabIndex = 487;
            this.label_subJuanNum.Text = "分卷号";
            // 
            // label_JuanNum
            // 
            this.label_JuanNum.AutoSize = true;
            this.label_JuanNum.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_JuanNum.ForeColor = System.Drawing.Color.Blue;
            this.label_JuanNum.Location = new System.Drawing.Point(47, 120);
            this.label_JuanNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_JuanNum.Name = "label_JuanNum";
            this.label_JuanNum.Size = new System.Drawing.Size(37, 20);
            this.label_JuanNum.TabIndex = 486;
            this.label_JuanNum.Text = "卷号";
            // 
            // label_Juan_Producton_EndTime
            // 
            this.label_Juan_Producton_EndTime.AutoSize = true;
            this.label_Juan_Producton_EndTime.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Juan_Producton_EndTime.Location = new System.Drawing.Point(5, 87);
            this.label_Juan_Producton_EndTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Juan_Producton_EndTime.Name = "label_Juan_Producton_EndTime";
            this.label_Juan_Producton_EndTime.Size = new System.Drawing.Size(79, 20);
            this.label_Juan_Producton_EndTime.TabIndex = 485;
            this.label_Juan_Producton_EndTime.Text = "卷结束时间";
            // 
            // label_JuanPorduceTime
            // 
            this.label_JuanPorduceTime.AutoSize = true;
            this.label_JuanPorduceTime.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_JuanPorduceTime.Location = new System.Drawing.Point(5, 53);
            this.label_JuanPorduceTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_JuanPorduceTime.Name = "label_JuanPorduceTime";
            this.label_JuanPorduceTime.Size = new System.Drawing.Size(79, 20);
            this.label_JuanPorduceTime.TabIndex = 484;
            this.label_JuanPorduceTime.Text = "卷生产时间";
            // 
            // btn_Linked
            // 
            this.btn_Linked.Location = new System.Drawing.Point(122, 60);
            this.btn_Linked.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_Linked.Name = "btn_Linked";
            this.btn_Linked.Size = new System.Drawing.Size(60, 26);
            this.btn_Linked.TabIndex = 478;
            this.btn_Linked.Text = "连接";
            this.btn_Linked.UseVisualStyleBackColor = true;
            this.btn_Linked.Click += new System.EventHandler(this.btn_Linked_Click_1);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(-2, 3);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 22);
            this.label15.TabIndex = 482;
            this.label15.Text = "带钢生产信息";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "同时",
            "全",
            "左",
            "中",
            "右"});
            this.comboBox1.Location = new System.Drawing.Point(585, 274);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 724;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // uiLabel38
            // 
            this.uiLabel38.BackColor = System.Drawing.SystemColors.ControlDark;
            this.uiLabel38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.uiLabel38.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel38.Location = new System.Drawing.Point(504, 270);
            this.uiLabel38.Name = "uiLabel38";
            this.uiLabel38.Size = new System.Drawing.Size(74, 27);
            this.uiLabel38.TabIndex = 725;
            this.uiLabel38.Text = "显示选择";
            this.uiLabel38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_Chart_Content
            // 
            this.panel_Chart_Content.BackColor = System.Drawing.Color.DimGray;
            this.panel_Chart_Content.Controls.Add(this.wb_leftchart);
            this.panel_Chart_Content.Controls.Add(this.panel_rightchart);
            this.panel_Chart_Content.Controls.Add(this.panel_midchart);
            this.panel_Chart_Content.Controls.Add(this.panel_fullchart);
            this.panel_Chart_Content.Location = new System.Drawing.Point(504, 300);
            this.panel_Chart_Content.Name = "panel_Chart_Content";
            this.panel_Chart_Content.Size = new System.Drawing.Size(1388, 717);
            this.panel_Chart_Content.TabIndex = 726;
            // 
            // wb_leftchart
            // 
            this.wb_leftchart.Location = new System.Drawing.Point(693, 1);
            this.wb_leftchart.MinimumSize = new System.Drawing.Size(20, 20);
            this.wb_leftchart.Name = "wb_leftchart";
            this.wb_leftchart.ScrollBarsEnabled = false;
            this.wb_leftchart.Size = new System.Drawing.Size(688, 357);
            this.wb_leftchart.TabIndex = 4;
            this.wb_leftchart.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.wb_leftchart_DocumentCompleted);
            // 
            // panel_rightchart
            // 
            this.panel_rightchart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_rightchart.Controls.Add(this.wb_rightchart);
            this.panel_rightchart.Location = new System.Drawing.Point(693, 359);
            this.panel_rightchart.Name = "panel_rightchart";
            this.panel_rightchart.Size = new System.Drawing.Size(690, 358);
            this.panel_rightchart.TabIndex = 3;
            // 
            // wb_rightchart
            // 
            this.wb_rightchart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wb_rightchart.Location = new System.Drawing.Point(0, 0);
            this.wb_rightchart.MinimumSize = new System.Drawing.Size(20, 20);
            this.wb_rightchart.Name = "wb_rightchart";
            this.wb_rightchart.ScrollBarsEnabled = false;
            this.wb_rightchart.Size = new System.Drawing.Size(688, 356);
            this.wb_rightchart.TabIndex = 0;
            // 
            // panel_midchart
            // 
            this.panel_midchart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_midchart.Controls.Add(this.wb_middlechart);
            this.panel_midchart.Location = new System.Drawing.Point(1, 359);
            this.panel_midchart.Name = "panel_midchart";
            this.panel_midchart.Size = new System.Drawing.Size(690, 358);
            this.panel_midchart.TabIndex = 1;
            // 
            // wb_middlechart
            // 
            this.wb_middlechart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wb_middlechart.Location = new System.Drawing.Point(0, 0);
            this.wb_middlechart.MinimumSize = new System.Drawing.Size(20, 20);
            this.wb_middlechart.Name = "wb_middlechart";
            this.wb_middlechart.ScrollBarsEnabled = false;
            this.wb_middlechart.Size = new System.Drawing.Size(688, 356);
            this.wb_middlechart.TabIndex = 0;
            // 
            // panel_fullchart
            // 
            this.panel_fullchart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_fullchart.Controls.Add(this.wb_fullchart);
            this.panel_fullchart.Location = new System.Drawing.Point(2, 0);
            this.panel_fullchart.Name = "panel_fullchart";
            this.panel_fullchart.Size = new System.Drawing.Size(690, 358);
            this.panel_fullchart.TabIndex = 0;
            // 
            // wb_fullchart
            // 
            this.wb_fullchart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wb_fullchart.Location = new System.Drawing.Point(0, 0);
            this.wb_fullchart.MinimumSize = new System.Drawing.Size(20, 20);
            this.wb_fullchart.Name = "wb_fullchart";
            this.wb_fullchart.ScrollBarsEnabled = false;
            this.wb_fullchart.Size = new System.Drawing.Size(688, 356);
            this.wb_fullchart.TabIndex = 0;
            this.wb_fullchart.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.wb_fullchart_DocumentCompleted);
            // 
            // panel_LIMS
            // 
            this.panel_LIMS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel_LIMS.Controls.Add(this.uiLabel18);
            this.panel_LIMS.Controls.Add(this.uiTextBox11);
            this.panel_LIMS.Controls.Add(this.uiTextBox2);
            this.panel_LIMS.Controls.Add(this.btn_LIMSS);
            this.panel_LIMS.Controls.Add(this.uiTextBox4);
            this.panel_LIMS.Controls.Add(this.uiTextBox5);
            this.panel_LIMS.Controls.Add(this.btn_selfTest);
            this.panel_LIMS.Controls.Add(this.uiTextBox6);
            this.panel_LIMS.Controls.Add(this.text_LIMS_a);
            this.panel_LIMS.Controls.Add(this.uiTextBox7);
            this.panel_LIMS.Controls.Add(this.text_SelfCheck_b);
            this.panel_LIMS.Controls.Add(this.uiTextBox8);
            this.panel_LIMS.Controls.Add(this.uiTextBox3);
            this.panel_LIMS.Controls.Add(this.label9);
            this.panel_LIMS.Controls.Add(this.uiTextBox15);
            this.panel_LIMS.Controls.Add(this.label8);
            this.panel_LIMS.Controls.Add(this.uiLabel21);
            this.panel_LIMS.Controls.Add(this.uiLabel20);
            this.panel_LIMS.Controls.Add(this.uiTextBox14);
            this.panel_LIMS.Controls.Add(this.uiLabel19);
            this.panel_LIMS.Controls.Add(this.text_SelfCheck_L);
            this.panel_LIMS.Controls.Add(this.uiLabel4);
            this.panel_LIMS.Controls.Add(this.uiLabel5);
            this.panel_LIMS.Controls.Add(this.text_SelfCheck_a);
            this.panel_LIMS.Controls.Add(this.uiLabel6);
            this.panel_LIMS.Controls.Add(this.text_LIMS_L);
            this.panel_LIMS.Controls.Add(this.uiLabel7);
            this.panel_LIMS.Controls.Add(this.text_LIMS_b);
            this.panel_LIMS.Controls.Add(this.uiTextBox9);
            this.panel_LIMS.Controls.Add(this.text_LIMS_ColorCode);
            this.panel_LIMS.Controls.Add(this.text_SelfCheck_ColorCode);
            this.panel_LIMS.Location = new System.Drawing.Point(1, 253);
            this.panel_LIMS.Name = "panel_LIMS";
            this.panel_LIMS.Size = new System.Drawing.Size(484, 135);
            this.panel_LIMS.TabIndex = 728;
            // 
            // uiLabel18
            // 
            this.uiLabel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiLabel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel18.Location = new System.Drawing.Point(371, 55);
            this.uiLabel18.Name = "uiLabel18";
            this.uiLabel18.Size = new System.Drawing.Size(61, 24);
            this.uiLabel18.TabIndex = 735;
            this.uiLabel18.Text = "取样位置";
            this.uiLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiTextBox11
            // 
            this.uiTextBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiTextBox11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiTextBox11.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox11.Location = new System.Drawing.Point(371, 104);
            this.uiTextBox11.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox11.Maximum = 2147483647D;
            this.uiTextBox11.Minimum = -2147483648D;
            this.uiTextBox11.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox11.Name = "uiTextBox11";
            this.uiTextBox11.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox11.RectColor = System.Drawing.Color.Black;
            this.uiTextBox11.Size = new System.Drawing.Size(61, 26);
            this.uiTextBox11.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox11.TabIndex = 596;
            // 
            // uiTextBox2
            // 
            this.uiTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox2.FillColor = System.Drawing.Color.White;
            this.uiTextBox2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox2.Location = new System.Drawing.Point(270, 104);
            this.uiTextBox2.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox2.Maximum = 2147483647D;
            this.uiTextBox2.Minimum = -2147483648D;
            this.uiTextBox2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox2.Name = "uiTextBox2";
            this.uiTextBox2.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox2.RectColor = System.Drawing.Color.Black;
            this.uiTextBox2.Size = new System.Drawing.Size(50, 26);
            this.uiTextBox2.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox2.TabIndex = 565;
            // 
            // btn_LIMSS
            // 
            this.btn_LIMSS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_LIMSS.FillColor = System.Drawing.Color.LightGray;
            this.btn_LIMSS.FillHoverColor = System.Drawing.SystemColors.ControlLight;
            this.btn_LIMSS.FillPressColor = System.Drawing.SystemColors.ControlLight;
            this.btn_LIMSS.FillSelectedColor = System.Drawing.SystemColors.ControlLight;
            this.btn_LIMSS.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btn_LIMSS.ForeColor = System.Drawing.Color.Black;
            this.btn_LIMSS.Location = new System.Drawing.Point(31, 28);
            this.btn_LIMSS.MinimumSize = new System.Drawing.Size(1, 1);
            this.btn_LIMSS.Name = "btn_LIMSS";
            this.btn_LIMSS.RectColor = System.Drawing.Color.Black;
            this.btn_LIMSS.Size = new System.Drawing.Size(105, 26);
            this.btn_LIMSS.Style = Sunny.UI.UIStyle.Custom;
            this.btn_LIMSS.TabIndex = 735;
            this.btn_LIMSS.Text = "4 LIMS";
            this.btn_LIMSS.Click += new System.EventHandler(this.btn_LIMSS_Click);
            // 
            // uiTextBox4
            // 
            this.uiTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox4.FillColor = System.Drawing.Color.White;
            this.uiTextBox4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox4.Location = new System.Drawing.Point(30, 104);
            this.uiTextBox4.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox4.Maximum = 2147483647D;
            this.uiTextBox4.Minimum = -2147483648D;
            this.uiTextBox4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox4.Name = "uiTextBox4";
            this.uiTextBox4.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox4.RectColor = System.Drawing.Color.Black;
            this.uiTextBox4.Size = new System.Drawing.Size(71, 26);
            this.uiTextBox4.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox4.TabIndex = 566;
            // 
            // uiTextBox5
            // 
            this.uiTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox5.FillColor = System.Drawing.Color.White;
            this.uiTextBox5.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox5.Location = new System.Drawing.Point(99, 104);
            this.uiTextBox5.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox5.Maximum = 2147483647D;
            this.uiTextBox5.Minimum = -2147483648D;
            this.uiTextBox5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox5.Name = "uiTextBox5";
            this.uiTextBox5.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox5.RectColor = System.Drawing.Color.Black;
            this.uiTextBox5.Size = new System.Drawing.Size(37, 26);
            this.uiTextBox5.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox5.TabIndex = 567;
            // 
            // btn_selfTest
            // 
            this.btn_selfTest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_selfTest.FillColor = System.Drawing.Color.LightGray;
            this.btn_selfTest.FillHoverColor = System.Drawing.SystemColors.ControlLight;
            this.btn_selfTest.FillPressColor = System.Drawing.SystemColors.ControlLight;
            this.btn_selfTest.FillSelectedColor = System.Drawing.SystemColors.ControlLight;
            this.btn_selfTest.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btn_selfTest.ForeColor = System.Drawing.Color.Black;
            this.btn_selfTest.Location = new System.Drawing.Point(31, 4);
            this.btn_selfTest.MinimumSize = new System.Drawing.Size(1, 1);
            this.btn_selfTest.Name = "btn_selfTest";
            this.btn_selfTest.RectColor = System.Drawing.Color.Black;
            this.btn_selfTest.Size = new System.Drawing.Size(105, 26);
            this.btn_selfTest.Style = Sunny.UI.UIStyle.Custom;
            this.btn_selfTest.TabIndex = 734;
            this.btn_selfTest.Text = "3 自对比";
            this.btn_selfTest.Click += new System.EventHandler(this.btn_selfTest_Click);
            // 
            // uiTextBox6
            // 
            this.uiTextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox6.FillColor = System.Drawing.Color.White;
            this.uiTextBox6.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox6.Location = new System.Drawing.Point(220, 104);
            this.uiTextBox6.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox6.Maximum = 2147483647D;
            this.uiTextBox6.Minimum = -2147483648D;
            this.uiTextBox6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox6.Name = "uiTextBox6";
            this.uiTextBox6.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox6.RectColor = System.Drawing.Color.Black;
            this.uiTextBox6.Size = new System.Drawing.Size(50, 26);
            this.uiTextBox6.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox6.TabIndex = 563;
            // 
            // uiTextBox7
            // 
            this.uiTextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox7.FillColor = System.Drawing.Color.White;
            this.uiTextBox7.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox7.Location = new System.Drawing.Point(321, 104);
            this.uiTextBox7.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox7.Maximum = 2147483647D;
            this.uiTextBox7.Minimum = -2147483648D;
            this.uiTextBox7.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox7.Name = "uiTextBox7";
            this.uiTextBox7.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox7.RectColor = System.Drawing.Color.Black;
            this.uiTextBox7.Size = new System.Drawing.Size(51, 26);
            this.uiTextBox7.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox7.TabIndex = 568;
            // 
            // uiTextBox8
            // 
            this.uiTextBox8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox8.FillColor = System.Drawing.Color.White;
            this.uiTextBox8.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox8.Location = new System.Drawing.Point(136, 104);
            this.uiTextBox8.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox8.Maximum = 2147483647D;
            this.uiTextBox8.Minimum = -2147483648D;
            this.uiTextBox8.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox8.Name = "uiTextBox8";
            this.uiTextBox8.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox8.RectColor = System.Drawing.Color.Black;
            this.uiTextBox8.Size = new System.Drawing.Size(84, 26);
            this.uiTextBox8.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox8.TabIndex = 564;
            // 
            // uiTextBox3
            // 
            this.uiTextBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiTextBox3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox3.Location = new System.Drawing.Point(371, 4);
            this.uiTextBox3.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox3.Maximum = 2147483647D;
            this.uiTextBox3.Minimum = -2147483648D;
            this.uiTextBox3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox3.Name = "uiTextBox3";
            this.uiTextBox3.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox3.RectColor = System.Drawing.Color.Black;
            this.uiTextBox3.Size = new System.Drawing.Size(61, 26);
            this.uiTextBox3.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox3.TabIndex = 595;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(1, 109);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 17);
            this.label9.TabIndex = 736;
            this.label9.Text = "筛选";
            // 
            // uiTextBox15
            // 
            this.uiTextBox15.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox15.FillColor = System.Drawing.Color.White;
            this.uiTextBox15.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox15.Location = new System.Drawing.Point(30, 79);
            this.uiTextBox15.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox15.Maximum = 2147483647D;
            this.uiTextBox15.Minimum = -2147483648D;
            this.uiTextBox15.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox15.Name = "uiTextBox15";
            this.uiTextBox15.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox15.RectColor = System.Drawing.Color.Black;
            this.uiTextBox15.Size = new System.Drawing.Size(71, 26);
            this.uiTextBox15.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox15.TabIndex = 559;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(2, 84);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 17);
            this.label8.TabIndex = 631;
            this.label8.Text = "实时";
            // 
            // uiLabel21
            // 
            this.uiLabel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiLabel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel21.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel21.Location = new System.Drawing.Point(101, 55);
            this.uiLabel21.Name = "uiLabel21";
            this.uiLabel21.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel21.Size = new System.Drawing.Size(35, 24);
            this.uiLabel21.TabIndex = 735;
            this.uiLabel21.Text = "分卷";
            this.uiLabel21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel20
            // 
            this.uiLabel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiLabel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel20.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel20.Location = new System.Drawing.Point(30, 55);
            this.uiLabel20.Name = "uiLabel20";
            this.uiLabel20.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel20.Size = new System.Drawing.Size(71, 24);
            this.uiLabel20.TabIndex = 734;
            this.uiLabel20.Text = "卷号";
            this.uiLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiTextBox14
            // 
            this.uiTextBox14.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox14.FillColor = System.Drawing.Color.White;
            this.uiTextBox14.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox14.Location = new System.Drawing.Point(100, 79);
            this.uiTextBox14.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox14.Maximum = 2147483647D;
            this.uiTextBox14.Minimum = -2147483648D;
            this.uiTextBox14.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox14.Name = "uiTextBox14";
            this.uiTextBox14.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox14.RectColor = System.Drawing.Color.Black;
            this.uiTextBox14.Size = new System.Drawing.Size(36, 26);
            this.uiTextBox14.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox14.TabIndex = 559;
            // 
            // uiLabel19
            // 
            this.uiLabel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.uiLabel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel19.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel19.Location = new System.Drawing.Point(432, 55);
            this.uiLabel19.Name = "uiLabel19";
            this.uiLabel19.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel19.Size = new System.Drawing.Size(46, 24);
            this.uiLabel19.TabIndex = 733;
            this.uiLabel19.Text = "∆E";
            this.uiLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel4
            // 
            this.uiLabel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiLabel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel4.Font = new System.Drawing.Font("微软雅黑", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel4.Location = new System.Drawing.Point(136, 55);
            this.uiLabel4.Name = "uiLabel4";
            this.uiLabel4.Size = new System.Drawing.Size(84, 24);
            this.uiLabel4.TabIndex = 729;
            this.uiLabel4.Text = "ColorCode";
            this.uiLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel5
            // 
            this.uiLabel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiLabel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel5.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel5.Location = new System.Drawing.Point(321, 55);
            this.uiLabel5.Name = "uiLabel5";
            this.uiLabel5.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel5.Size = new System.Drawing.Size(50, 24);
            this.uiLabel5.TabIndex = 732;
            this.uiLabel5.Text = "b";
            this.uiLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel6
            // 
            this.uiLabel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.uiLabel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel6.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel6.Location = new System.Drawing.Point(270, 55);
            this.uiLabel6.Name = "uiLabel6";
            this.uiLabel6.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel6.Size = new System.Drawing.Size(50, 24);
            this.uiLabel6.TabIndex = 731;
            this.uiLabel6.Text = "a";
            this.uiLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel7
            // 
            this.uiLabel7.BackColor = System.Drawing.SystemColors.Control;
            this.uiLabel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel7.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel7.Location = new System.Drawing.Point(220, 55);
            this.uiLabel7.Name = "uiLabel7";
            this.uiLabel7.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel7.Size = new System.Drawing.Size(50, 24);
            this.uiLabel7.TabIndex = 730;
            this.uiLabel7.Text = "L";
            this.uiLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiTextBox9
            // 
            this.uiTextBox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox9.FillColor = System.Drawing.Color.White;
            this.uiTextBox9.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox9.Location = new System.Drawing.Point(431, 79);
            this.uiTextBox9.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox9.Maximum = 2147483647D;
            this.uiTextBox9.Minimum = -2147483648D;
            this.uiTextBox9.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox9.Name = "uiTextBox9";
            this.uiTextBox9.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox9.RectColor = System.Drawing.Color.Black;
            this.uiTextBox9.Size = new System.Drawing.Size(46, 26);
            this.uiTextBox9.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox9.TabIndex = 597;
            // 
            // panel_ColorStadard
            // 
            this.panel_ColorStadard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_ColorStadard.Controls.Add(this.btn_rengongInput);
            this.panel_ColorStadard.Controls.Add(this.panel_LIMS);
            this.panel_ColorStadard.Controls.Add(this.uiLabel3);
            this.panel_ColorStadard.Controls.Add(label_GDB);
            this.panel_ColorStadard.Controls.Add(this.text_LetPassDeviationValue_b);
            this.panel_ColorStadard.Controls.Add(this.label_DBRectify);
            this.panel_ColorStadard.Controls.Add(this.text_LetPassDeviationValue_a);
            this.panel_ColorStadard.Controls.Add(this.uiTextBox12);
            this.panel_ColorStadard.Controls.Add(this.uiTextBox10);
            this.panel_ColorStadard.Controls.Add(this.text_LetPassValue_b);
            this.panel_ColorStadard.Controls.Add(this.text_Manualinput_L);
            this.panel_ColorStadard.Controls.Add(this.text_LetPassValue_a);
            this.panel_ColorStadard.Controls.Add(this.text_Manualinput_a);
            this.panel_ColorStadard.Controls.Add(this.text_LetPassValue_L);
            this.panel_ColorStadard.Controls.Add(this.uiLabel1);
            this.panel_ColorStadard.Controls.Add(this.text_Manualinput_b);
            this.panel_ColorStadard.Controls.Add(this.uiLabel2);
            this.panel_ColorStadard.Controls.Add(this.label25);
            this.panel_ColorStadard.Controls.Add(this.text_Manualinput_ColorCode);
            this.panel_ColorStadard.Controls.Add(this.label35);
            this.panel_ColorStadard.Controls.Add(this.uiLabel12);
            this.panel_ColorStadard.Controls.Add(this.uiLabel13);
            this.panel_ColorStadard.Controls.Add(this.text_GDB3_L);
            this.panel_ColorStadard.Controls.Add(this.uiLabel10);
            this.panel_ColorStadard.Controls.Add(this.text_GDB3_a);
            this.panel_ColorStadard.Controls.Add(this.uiLabel11);
            this.panel_ColorStadard.Controls.Add(this.text_GDB2_L);
            this.panel_ColorStadard.Controls.Add(this.text_LetPassDeviationValue_L);
            this.panel_ColorStadard.Controls.Add(this.text_GDB3_b);
            this.panel_ColorStadard.Controls.Add(this.uiLabel8);
            this.panel_ColorStadard.Controls.Add(this.text_GDB2_a);
            this.panel_ColorStadard.Controls.Add(this.uiLabel9);
            this.panel_ColorStadard.Controls.Add(this.text_GDB3_ColorCode);
            this.panel_ColorStadard.Controls.Add(this.uiLabel14);
            this.panel_ColorStadard.Controls.Add(this.text_GDB1_L);
            this.panel_ColorStadard.Controls.Add(this.text_GDB2_b);
            this.panel_ColorStadard.Controls.Add(this.text_GDB1_a);
            this.panel_ColorStadard.Controls.Add(this.uiLabel17);
            this.panel_ColorStadard.Controls.Add(this.text_GDB2_ColorCode);
            this.panel_ColorStadard.Controls.Add(this.text_GDB1_b);
            this.panel_ColorStadard.Controls.Add(this.uiLabel16);
            this.panel_ColorStadard.Controls.Add(this.text_GDB1_ColorCode);
            this.panel_ColorStadard.Controls.Add(this.label_GDB3);
            this.panel_ColorStadard.Controls.Add(this.uiLabel15);
            this.panel_ColorStadard.Controls.Add(this.label_GDB1);
            this.panel_ColorStadard.Controls.Add(this.text_DBRectify_b);
            this.panel_ColorStadard.Controls.Add(this.text_DBRectify_L);
            this.panel_ColorStadard.Controls.Add(this.text_DBRectify_a);
            this.panel_ColorStadard.Controls.Add(this.label_GDB2);
            this.panel_ColorStadard.Location = new System.Drawing.Point(2, 539);
            this.panel_ColorStadard.Name = "panel_ColorStadard";
            this.panel_ColorStadard.Size = new System.Drawing.Size(498, 399);
            this.panel_ColorStadard.TabIndex = 729;
            // 
            // btn_rengongInput
            // 
            this.btn_rengongInput.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_rengongInput.FillColor = System.Drawing.Color.LightGray;
            this.btn_rengongInput.FillHoverColor = System.Drawing.SystemColors.ControlLight;
            this.btn_rengongInput.FillPressColor = System.Drawing.SystemColors.ControlLight;
            this.btn_rengongInput.FillSelectedColor = System.Drawing.SystemColors.ControlLight;
            this.btn_rengongInput.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btn_rengongInput.ForeColor = System.Drawing.Color.Black;
            this.btn_rengongInput.Location = new System.Drawing.Point(32, 120);
            this.btn_rengongInput.MinimumSize = new System.Drawing.Size(1, 1);
            this.btn_rengongInput.Name = "btn_rengongInput";
            this.btn_rengongInput.RectColor = System.Drawing.Color.Black;
            this.btn_rengongInput.Size = new System.Drawing.Size(105, 26);
            this.btn_rengongInput.Style = Sunny.UI.UIStyle.Custom;
            this.btn_rengongInput.TabIndex = 733;
            this.btn_rengongInput.Text = "1 人工输入";
            this.btn_rengongInput.Click += new System.EventHandler(this.btn_rengongInput_Click);
            // 
            // uiLabel3
            // 
            this.uiLabel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel3.Location = new System.Drawing.Point(374, 226);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Padding = new System.Windows.Forms.Padding(1);
            this.uiLabel3.Size = new System.Drawing.Size(61, 24);
            this.uiLabel3.TabIndex = 601;
            this.uiLabel3.Text = "取样位置";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_LetPassDeviationValue_b
            // 
            this.text_LetPassDeviationValue_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LetPassDeviationValue_b.FillColor = System.Drawing.Color.White;
            this.text_LetPassDeviationValue_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LetPassDeviationValue_b.Location = new System.Drawing.Point(296, 29);
            this.text_LetPassDeviationValue_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LetPassDeviationValue_b.Maximum = 2147483647D;
            this.text_LetPassDeviationValue_b.Minimum = -2147483648D;
            this.text_LetPassDeviationValue_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LetPassDeviationValue_b.Name = "text_LetPassDeviationValue_b";
            this.text_LetPassDeviationValue_b.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LetPassDeviationValue_b.RectColor = System.Drawing.Color.Black;
            this.text_LetPassDeviationValue_b.Size = new System.Drawing.Size(50, 26);
            this.text_LetPassDeviationValue_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_LetPassDeviationValue_b.TabIndex = 581;
            // 
            // text_LetPassDeviationValue_a
            // 
            this.text_LetPassDeviationValue_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LetPassDeviationValue_a.FillColor = System.Drawing.Color.White;
            this.text_LetPassDeviationValue_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LetPassDeviationValue_a.Location = new System.Drawing.Point(205, 29);
            this.text_LetPassDeviationValue_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LetPassDeviationValue_a.Maximum = 2147483647D;
            this.text_LetPassDeviationValue_a.Minimum = -2147483648D;
            this.text_LetPassDeviationValue_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LetPassDeviationValue_a.Name = "text_LetPassDeviationValue_a";
            this.text_LetPassDeviationValue_a.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LetPassDeviationValue_a.RectColor = System.Drawing.Color.Black;
            this.text_LetPassDeviationValue_a.Size = new System.Drawing.Size(50, 26);
            this.text_LetPassDeviationValue_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_LetPassDeviationValue_a.TabIndex = 581;
            // 
            // uiTextBox12
            // 
            this.uiTextBox12.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox12.FillColor = System.Drawing.Color.White;
            this.uiTextBox12.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox12.Location = new System.Drawing.Point(385, 66);
            this.uiTextBox12.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox12.Maximum = 2147483647D;
            this.uiTextBox12.Minimum = -2147483648D;
            this.uiTextBox12.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox12.Name = "uiTextBox12";
            this.uiTextBox12.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox12.RectColor = System.Drawing.Color.Black;
            this.uiTextBox12.Size = new System.Drawing.Size(50, 26);
            this.uiTextBox12.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox12.TabIndex = 581;
            // 
            // uiTextBox10
            // 
            this.uiTextBox10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox10.FillColor = System.Drawing.Color.White;
            this.uiTextBox10.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox10.Location = new System.Drawing.Point(387, 29);
            this.uiTextBox10.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox10.Maximum = 2147483647D;
            this.uiTextBox10.Minimum = -2147483648D;
            this.uiTextBox10.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox10.Name = "uiTextBox10";
            this.uiTextBox10.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox10.RectColor = System.Drawing.Color.Black;
            this.uiTextBox10.Size = new System.Drawing.Size(50, 26);
            this.uiTextBox10.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox10.TabIndex = 581;
            // 
            // text_LetPassValue_b
            // 
            this.text_LetPassValue_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LetPassValue_b.FillColor = System.Drawing.Color.White;
            this.text_LetPassValue_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LetPassValue_b.Location = new System.Drawing.Point(296, 66);
            this.text_LetPassValue_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LetPassValue_b.Maximum = 2147483647D;
            this.text_LetPassValue_b.Minimum = -2147483648D;
            this.text_LetPassValue_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LetPassValue_b.Name = "text_LetPassValue_b";
            this.text_LetPassValue_b.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LetPassValue_b.RectColor = System.Drawing.Color.Black;
            this.text_LetPassValue_b.Size = new System.Drawing.Size(50, 26);
            this.text_LetPassValue_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_LetPassValue_b.TabIndex = 581;
            // 
            // text_LetPassValue_a
            // 
            this.text_LetPassValue_a.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LetPassValue_a.FillColor = System.Drawing.Color.White;
            this.text_LetPassValue_a.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LetPassValue_a.Location = new System.Drawing.Point(205, 66);
            this.text_LetPassValue_a.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LetPassValue_a.Maximum = 2147483647D;
            this.text_LetPassValue_a.Minimum = -2147483648D;
            this.text_LetPassValue_a.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LetPassValue_a.Name = "text_LetPassValue_a";
            this.text_LetPassValue_a.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LetPassValue_a.RectColor = System.Drawing.Color.Black;
            this.text_LetPassValue_a.Size = new System.Drawing.Size(50, 26);
            this.text_LetPassValue_a.Style = Sunny.UI.UIStyle.Custom;
            this.text_LetPassValue_a.TabIndex = 581;
            // 
            // text_LetPassValue_L
            // 
            this.text_LetPassValue_L.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_LetPassValue_L.FillColor = System.Drawing.Color.White;
            this.text_LetPassValue_L.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_LetPassValue_L.Location = new System.Drawing.Point(113, 66);
            this.text_LetPassValue_L.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_LetPassValue_L.Maximum = 2147483647D;
            this.text_LetPassValue_L.Minimum = -2147483648D;
            this.text_LetPassValue_L.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_LetPassValue_L.Name = "text_LetPassValue_L";
            this.text_LetPassValue_L.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_LetPassValue_L.RectColor = System.Drawing.Color.Black;
            this.text_LetPassValue_L.Size = new System.Drawing.Size(50, 26);
            this.text_LetPassValue_L.Style = Sunny.UI.UIStyle.Custom;
            this.text_LetPassValue_L.TabIndex = 593;
            // 
            // uiLabel1
            // 
            this.uiLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.uiLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel1.Location = new System.Drawing.Point(346, 29);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(41, 26);
            this.uiLabel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel1.TabIndex = 592;
            this.uiLabel1.Text = "∆E*";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_Manualinput_b
            // 
            this.text_Manualinput_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_Manualinput_b.FillColor = System.Drawing.Color.White;
            this.text_Manualinput_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_Manualinput_b.Location = new System.Drawing.Point(325, 120);
            this.text_Manualinput_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_Manualinput_b.Maximum = 2147483647D;
            this.text_Manualinput_b.Minimum = -2147483648D;
            this.text_Manualinput_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_Manualinput_b.Name = "text_Manualinput_b";
            this.text_Manualinput_b.Padding = new System.Windows.Forms.Padding(5);
            this.text_Manualinput_b.RectColor = System.Drawing.Color.Black;
            this.text_Manualinput_b.Size = new System.Drawing.Size(50, 26);
            this.text_Manualinput_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_Manualinput_b.TabIndex = 550;
            // 
            // uiLabel2
            // 
            this.uiLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.uiLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel2.Location = new System.Drawing.Point(346, 66);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Padding = new System.Windows.Forms.Padding(2);
            this.uiLabel2.Size = new System.Drawing.Size(41, 26);
            this.uiLabel2.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel2.TabIndex = 591;
            this.uiLabel2.Text = "b_C";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_GDB3_b
            // 
            this.text_GDB3_b.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_GDB3_b.FillColor = System.Drawing.Color.White;
            this.text_GDB3_b.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_GDB3_b.Location = new System.Drawing.Point(324, 146);
            this.text_GDB3_b.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_GDB3_b.Maximum = 2147483647D;
            this.text_GDB3_b.Minimum = -2147483648D;
            this.text_GDB3_b.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_GDB3_b.Name = "text_GDB3_b";
            this.text_GDB3_b.Padding = new System.Windows.Forms.Padding(5);
            this.text_GDB3_b.RectColor = System.Drawing.Color.Black;
            this.text_GDB3_b.Size = new System.Drawing.Size(50, 26);
            this.text_GDB3_b.Style = Sunny.UI.UIStyle.Custom;
            this.text_GDB3_b.TabIndex = 561;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btn_linkLocal);
            this.panel1.Controls.Add(this.uiButton1);
            this.panel1.Controls.Add(this.uiTextBox49);
            this.panel1.Controls.Add(this.text_IfGood);
            this.panel1.Controls.Add(this.uiTextBox48);
            this.panel1.Controls.Add(this.uiTextBox45);
            this.panel1.Controls.Add(this.uiTextBox44);
            this.panel1.Controls.Add(this.uiTextBox41);
            this.panel1.Controls.Add(this.uiTextBox40);
            this.panel1.Controls.Add(this.uiTextBox47);
            this.panel1.Controls.Add(this.uiTextBox34);
            this.panel1.Controls.Add(this.uiTextBox43);
            this.panel1.Controls.Add(this.uiTextBox35);
            this.panel1.Controls.Add(this.uiTextBox39);
            this.panel1.Controls.Add(this.uiTextBox46);
            this.panel1.Controls.Add(this.text_ColorCode);
            this.panel1.Controls.Add(this.uiTextBox42);
            this.panel1.Controls.Add(this.uiTextBox36);
            this.panel1.Controls.Add(this.uiTextBox38);
            this.panel1.Controls.Add(this.Text_NotCheckNum);
            this.panel1.Controls.Add(this.uiTextBox37);
            this.panel1.Controls.Add(this.Text_NotGoodNum);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Text_CheckNum);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label_JuanPorduceTime);
            this.panel1.Controls.Add(this.label_Juan_Producton_EndTime);
            this.panel1.Controls.Add(this.label_JuanNum);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label_subJuanNum);
            this.panel1.Controls.Add(this.label_JuanLength);
            this.panel1.Controls.Add(this.label_JuanWidth);
            this.panel1.Controls.Add(this.label_JuanThickness);
            this.panel1.Controls.Add(this.label_JuanBroadwise);
            this.panel1.Controls.Add(this.label_ColorCode);
            this.panel1.Controls.Add(this.label_CurrentValue);
            this.panel1.Controls.Add(this.label_DeviationValue);
            this.panel1.Controls.Add(this.uiLabel33);
            this.panel1.Controls.Add(this.uiLabel32);
            this.panel1.Controls.Add(this.text_CurrentValue_L);
            this.panel1.Controls.Add(this.text_CurrentValue_a);
            this.panel1.Controls.Add(this.text_DeviationValue_L);
            this.panel1.Controls.Add(this.text_CurrentValue_b);
            this.panel1.Controls.Add(this.text_DeviationValue_a);
            this.panel1.Controls.Add(this.text_DeviationValue_b);
            this.panel1.Controls.Add(this.uiLabel31);
            this.panel1.Controls.Add(this.text_JuanBroadwise);
            this.panel1.Controls.Add(this.uiLabel30);
            this.panel1.Controls.Add(this.text_JuanWidth);
            this.panel1.Controls.Add(this.uiLabel29);
            this.panel1.Controls.Add(this.text_SubJuanNum);
            this.panel1.Controls.Add(this.uiLabel28);
            this.panel1.Controls.Add(this.text_JuanProduceEndtime);
            this.panel1.Controls.Add(this.uiLabel34);
            this.panel1.Controls.Add(this.text_JuanThickness);
            this.panel1.Controls.Add(this.text_StandardDeviation);
            this.panel1.Controls.Add(this.text_JuanLength);
            this.panel1.Controls.Add(this.text_JuanPorduceTime);
            this.panel1.Controls.Add(this.text_JuanNum);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Location = new System.Drawing.Point(4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(498, 528);
            this.panel1.TabIndex = 730;
            // 
            // btn_linkLocal
            // 
            this.btn_linkLocal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_linkLocal.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.btn_linkLocal.Location = new System.Drawing.Point(195, 6);
            this.btn_linkLocal.MinimumSize = new System.Drawing.Size(1, 1);
            this.btn_linkLocal.Name = "btn_linkLocal";
            this.btn_linkLocal.Size = new System.Drawing.Size(117, 35);
            this.btn_linkLocal.TabIndex = 738;
            this.btn_linkLocal.Text = "连接本地测试";
            this.btn_linkLocal.Click += new System.EventHandler(this.btn_linkLocal_Click);
            // 
            // uiButton1
            // 
            this.uiButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton1.Location = new System.Drawing.Point(325, 6);
            this.uiButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton1.Name = "uiButton1";
            this.uiButton1.Size = new System.Drawing.Size(119, 35);
            this.uiButton1.TabIndex = 737;
            this.uiButton1.Text = "连接现场测试";
            // 
            // uiTextBox49
            // 
            this.uiTextBox49.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox49.FillColor = System.Drawing.Color.White;
            this.uiTextBox49.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox49.Location = new System.Drawing.Point(88, 373);
            this.uiTextBox49.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox49.Maximum = 2147483647D;
            this.uiTextBox49.Minimum = -2147483648D;
            this.uiTextBox49.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox49.Name = "uiTextBox49";
            this.uiTextBox49.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox49.RectColor = System.Drawing.Color.Black;
            this.uiTextBox49.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox49.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox49.TabIndex = 616;
            this.uiTextBox49.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox48
            // 
            this.uiTextBox48.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox48.FillColor = System.Drawing.Color.White;
            this.uiTextBox48.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox48.Location = new System.Drawing.Point(158, 373);
            this.uiTextBox48.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox48.Maximum = 2147483647D;
            this.uiTextBox48.Minimum = -2147483648D;
            this.uiTextBox48.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox48.Name = "uiTextBox48";
            this.uiTextBox48.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox48.RectColor = System.Drawing.Color.Black;
            this.uiTextBox48.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox48.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox48.TabIndex = 617;
            this.uiTextBox48.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox45
            // 
            this.uiTextBox45.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox45.FillColor = System.Drawing.Color.White;
            this.uiTextBox45.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox45.Location = new System.Drawing.Point(88, 347);
            this.uiTextBox45.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox45.Maximum = 2147483647D;
            this.uiTextBox45.Minimum = -2147483648D;
            this.uiTextBox45.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox45.Name = "uiTextBox45";
            this.uiTextBox45.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox45.RectColor = System.Drawing.Color.Black;
            this.uiTextBox45.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox45.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox45.TabIndex = 616;
            this.uiTextBox45.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox44
            // 
            this.uiTextBox44.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox44.FillColor = System.Drawing.Color.White;
            this.uiTextBox44.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox44.Location = new System.Drawing.Point(158, 347);
            this.uiTextBox44.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox44.Maximum = 2147483647D;
            this.uiTextBox44.Minimum = -2147483648D;
            this.uiTextBox44.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox44.Name = "uiTextBox44";
            this.uiTextBox44.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox44.RectColor = System.Drawing.Color.Black;
            this.uiTextBox44.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox44.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox44.TabIndex = 617;
            this.uiTextBox44.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox41
            // 
            this.uiTextBox41.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox41.FillColor = System.Drawing.Color.White;
            this.uiTextBox41.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox41.Location = new System.Drawing.Point(88, 321);
            this.uiTextBox41.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox41.Maximum = 2147483647D;
            this.uiTextBox41.Minimum = -2147483648D;
            this.uiTextBox41.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox41.Name = "uiTextBox41";
            this.uiTextBox41.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox41.RectColor = System.Drawing.Color.Black;
            this.uiTextBox41.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox41.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox41.TabIndex = 616;
            this.uiTextBox41.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox40
            // 
            this.uiTextBox40.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox40.FillColor = System.Drawing.Color.White;
            this.uiTextBox40.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox40.Location = new System.Drawing.Point(158, 321);
            this.uiTextBox40.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox40.Maximum = 2147483647D;
            this.uiTextBox40.Minimum = -2147483648D;
            this.uiTextBox40.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox40.Name = "uiTextBox40";
            this.uiTextBox40.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox40.RectColor = System.Drawing.Color.Black;
            this.uiTextBox40.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox40.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox40.TabIndex = 617;
            this.uiTextBox40.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox47
            // 
            this.uiTextBox47.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox47.FillColor = System.Drawing.Color.White;
            this.uiTextBox47.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox47.Location = new System.Drawing.Point(228, 373);
            this.uiTextBox47.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox47.Maximum = 2147483647D;
            this.uiTextBox47.Minimum = -2147483648D;
            this.uiTextBox47.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox47.Name = "uiTextBox47";
            this.uiTextBox47.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox47.RectColor = System.Drawing.Color.Black;
            this.uiTextBox47.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox47.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox47.TabIndex = 618;
            this.uiTextBox47.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox34
            // 
            this.uiTextBox34.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox34.FillColor = System.Drawing.Color.White;
            this.uiTextBox34.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox34.Location = new System.Drawing.Point(88, 295);
            this.uiTextBox34.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox34.Maximum = 2147483647D;
            this.uiTextBox34.Minimum = -2147483648D;
            this.uiTextBox34.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox34.Name = "uiTextBox34";
            this.uiTextBox34.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox34.RectColor = System.Drawing.Color.Black;
            this.uiTextBox34.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox34.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox34.TabIndex = 616;
            this.uiTextBox34.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox43
            // 
            this.uiTextBox43.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox43.FillColor = System.Drawing.Color.White;
            this.uiTextBox43.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox43.Location = new System.Drawing.Point(228, 347);
            this.uiTextBox43.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox43.Maximum = 2147483647D;
            this.uiTextBox43.Minimum = -2147483648D;
            this.uiTextBox43.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox43.Name = "uiTextBox43";
            this.uiTextBox43.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox43.RectColor = System.Drawing.Color.Black;
            this.uiTextBox43.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox43.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox43.TabIndex = 618;
            this.uiTextBox43.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox35
            // 
            this.uiTextBox35.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox35.FillColor = System.Drawing.Color.White;
            this.uiTextBox35.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox35.Location = new System.Drawing.Point(158, 295);
            this.uiTextBox35.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox35.Maximum = 2147483647D;
            this.uiTextBox35.Minimum = -2147483648D;
            this.uiTextBox35.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox35.Name = "uiTextBox35";
            this.uiTextBox35.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox35.RectColor = System.Drawing.Color.Black;
            this.uiTextBox35.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox35.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox35.TabIndex = 617;
            this.uiTextBox35.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox39
            // 
            this.uiTextBox39.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox39.FillColor = System.Drawing.Color.White;
            this.uiTextBox39.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox39.Location = new System.Drawing.Point(228, 321);
            this.uiTextBox39.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox39.Maximum = 2147483647D;
            this.uiTextBox39.Minimum = -2147483648D;
            this.uiTextBox39.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox39.Name = "uiTextBox39";
            this.uiTextBox39.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox39.RectColor = System.Drawing.Color.Black;
            this.uiTextBox39.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox39.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox39.TabIndex = 618;
            this.uiTextBox39.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox46
            // 
            this.uiTextBox46.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox46.FillColor = System.Drawing.Color.White;
            this.uiTextBox46.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox46.Location = new System.Drawing.Point(296, 373);
            this.uiTextBox46.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox46.Maximum = 2147483647D;
            this.uiTextBox46.Minimum = -2147483648D;
            this.uiTextBox46.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox46.Name = "uiTextBox46";
            this.uiTextBox46.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox46.RectColor = System.Drawing.Color.Black;
            this.uiTextBox46.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox46.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox46.TabIndex = 615;
            this.uiTextBox46.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // text_ColorCode
            // 
            this.text_ColorCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.text_ColorCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_ColorCode.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.text_ColorCode.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_ColorCode.Location = new System.Drawing.Point(88, 185);
            this.text_ColorCode.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_ColorCode.Maximum = 2147483647D;
            this.text_ColorCode.Minimum = -2147483648D;
            this.text_ColorCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_ColorCode.Name = "text_ColorCode";
            this.text_ColorCode.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_ColorCode.RectColor = System.Drawing.Color.Black;
            this.text_ColorCode.Size = new System.Drawing.Size(157, 26);
            this.text_ColorCode.Style = Sunny.UI.UIStyle.Custom;
            this.text_ColorCode.TabIndex = 624;
            this.text_ColorCode.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox42
            // 
            this.uiTextBox42.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox42.FillColor = System.Drawing.Color.White;
            this.uiTextBox42.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox42.Location = new System.Drawing.Point(296, 347);
            this.uiTextBox42.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox42.Maximum = 2147483647D;
            this.uiTextBox42.Minimum = -2147483648D;
            this.uiTextBox42.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox42.Name = "uiTextBox42";
            this.uiTextBox42.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox42.RectColor = System.Drawing.Color.Black;
            this.uiTextBox42.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox42.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox42.TabIndex = 615;
            this.uiTextBox42.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox36
            // 
            this.uiTextBox36.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox36.FillColor = System.Drawing.Color.White;
            this.uiTextBox36.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox36.Location = new System.Drawing.Point(228, 295);
            this.uiTextBox36.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox36.Maximum = 2147483647D;
            this.uiTextBox36.Minimum = -2147483648D;
            this.uiTextBox36.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox36.Name = "uiTextBox36";
            this.uiTextBox36.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox36.RectColor = System.Drawing.Color.Black;
            this.uiTextBox36.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox36.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox36.TabIndex = 618;
            this.uiTextBox36.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox38
            // 
            this.uiTextBox38.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox38.FillColor = System.Drawing.Color.White;
            this.uiTextBox38.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox38.Location = new System.Drawing.Point(296, 321);
            this.uiTextBox38.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox38.Maximum = 2147483647D;
            this.uiTextBox38.Minimum = -2147483648D;
            this.uiTextBox38.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox38.Name = "uiTextBox38";
            this.uiTextBox38.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox38.RectColor = System.Drawing.Color.Black;
            this.uiTextBox38.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox38.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox38.TabIndex = 615;
            this.uiTextBox38.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Text_NotCheckNum
            // 
            this.Text_NotCheckNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Text_NotCheckNum.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Text_NotCheckNum.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Text_NotCheckNum.Location = new System.Drawing.Point(366, 412);
            this.Text_NotCheckNum.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.Text_NotCheckNum.Maximum = 2147483647D;
            this.Text_NotCheckNum.Minimum = -2147483648D;
            this.Text_NotCheckNum.MinimumSize = new System.Drawing.Size(1, 1);
            this.Text_NotCheckNum.Name = "Text_NotCheckNum";
            this.Text_NotCheckNum.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Text_NotCheckNum.RectColor = System.Drawing.Color.Black;
            this.Text_NotCheckNum.Size = new System.Drawing.Size(70, 26);
            this.Text_NotCheckNum.Style = Sunny.UI.UIStyle.Custom;
            this.Text_NotCheckNum.TabIndex = 611;
            this.Text_NotCheckNum.Text = "0";
            this.Text_NotCheckNum.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // uiTextBox37
            // 
            this.uiTextBox37.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox37.FillColor = System.Drawing.Color.White;
            this.uiTextBox37.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBox37.Location = new System.Drawing.Point(296, 295);
            this.uiTextBox37.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.uiTextBox37.Maximum = 2147483647D;
            this.uiTextBox37.Minimum = -2147483648D;
            this.uiTextBox37.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTextBox37.Name = "uiTextBox37";
            this.uiTextBox37.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.uiTextBox37.RectColor = System.Drawing.Color.Black;
            this.uiTextBox37.Size = new System.Drawing.Size(70, 26);
            this.uiTextBox37.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBox37.TabIndex = 615;
            this.uiTextBox37.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Text_NotGoodNum
            // 
            this.Text_NotGoodNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Text_NotGoodNum.DoubleValue = 1D;
            this.Text_NotGoodNum.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Text_NotGoodNum.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Text_NotGoodNum.IntValue = 1;
            this.Text_NotGoodNum.Location = new System.Drawing.Point(228, 412);
            this.Text_NotGoodNum.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.Text_NotGoodNum.Maximum = 2147483647D;
            this.Text_NotGoodNum.Minimum = -2147483648D;
            this.Text_NotGoodNum.MinimumSize = new System.Drawing.Size(1, 1);
            this.Text_NotGoodNum.Name = "Text_NotGoodNum";
            this.Text_NotGoodNum.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Text_NotGoodNum.RectColor = System.Drawing.Color.Black;
            this.Text_NotGoodNum.Size = new System.Drawing.Size(70, 26);
            this.Text_NotGoodNum.Style = Sunny.UI.UIStyle.Custom;
            this.Text_NotGoodNum.TabIndex = 610;
            this.Text_NotGoodNum.Text = "1";
            this.Text_NotGoodNum.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(30, 324);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 734;
            this.label2.Text = "操作侧";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(30, 298);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 631;
            this.label1.Text = "传动侧";
            // 
            // Text_CheckNum
            // 
            this.Text_CheckNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Text_CheckNum.DoubleValue = 12D;
            this.Text_CheckNum.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Text_CheckNum.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Text_CheckNum.IntValue = 12;
            this.Text_CheckNum.Location = new System.Drawing.Point(88, 412);
            this.Text_CheckNum.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.Text_CheckNum.Maximum = 2147483647D;
            this.Text_CheckNum.Minimum = -2147483648D;
            this.Text_CheckNum.MinimumSize = new System.Drawing.Size(1, 1);
            this.Text_CheckNum.Name = "Text_CheckNum";
            this.Text_CheckNum.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Text_CheckNum.RectColor = System.Drawing.Color.Black;
            this.Text_CheckNum.Size = new System.Drawing.Size(70, 26);
            this.Text_CheckNum.Style = Sunny.UI.UIStyle.Custom;
            this.Text_CheckNum.TabIndex = 609;
            this.Text_CheckNum.Text = "12";
            this.Text_CheckNum.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(44, 350);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 20);
            this.label12.TabIndex = 735;
            this.label12.Text = "差值";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(21, 415);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 20);
            this.label7.TabIndex = 630;
            this.label7.Text = "检测数量";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(158, 417);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 629;
            this.label6.Text = "不合格数量";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(300, 415);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 20);
            this.label5.TabIndex = 628;
            this.label5.Text = "漏检数量";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(44, 376);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 20);
            this.label13.TabIndex = 736;
            this.label13.Text = "计数";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.label_OpeningPlus);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.pic_LLLPosition);
            this.panel2.Controls.Add(this.textBox5);
            this.panel2.Controls.Add(this.pictureBox8);
            this.panel2.Controls.Add(this.btn_GDB3);
            this.panel2.Controls.Add(this.btn_GDB2);
            this.panel2.Controls.Add(this.btn_GDB1);
            this.panel2.Controls.Add(this.btn_Manualinput);
            this.panel2.Controls.Add(this.btn_Black);
            this.panel2.Controls.Add(this.btn_White);
            this.panel2.Controls.Add(this.btn_Center);
            this.panel2.Controls.Add(this.label_TechnicSpeed);
            this.panel2.Controls.Add(this.text_TechnicSpeed);
            this.panel2.Controls.Add(this.text_RightPosition);
            this.panel2.Controls.Add(this.label_ExportSpeed);
            this.panel2.Controls.Add(this.text_leftPosition);
            this.panel2.Controls.Add(this.text_ExportSpeed);
            this.panel2.Controls.Add(this.pic_RightPosition);
            this.panel2.Controls.Add(this.pic_Rightbar);
            this.panel2.Controls.Add(this.pictureBox9);
            this.panel2.Controls.Add(this.pictureBox7);
            this.panel2.Controls.Add(this.label_Position);
            this.panel2.Controls.Add(this.uiLabel23);
            this.panel2.Controls.Add(this.label_OperateMove);
            this.panel2.Controls.Add(this.uiLabel22);
            this.panel2.Controls.Add(this.label_DriveMove);
            this.panel2.Controls.Add(this.label_OpeningSub);
            this.panel2.Location = new System.Drawing.Point(1466, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(422, 292);
            this.panel2.TabIndex = 731;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.btn_HanFeng6);
            this.panel6.Controls.Add(this.text_Dodgelength);
            this.panel6.Controls.Add(this.label_Dodgelength);
            this.panel6.Controls.Add(this.text_HanFeng5);
            this.panel6.Controls.Add(this.text_HanFeng6);
            this.panel6.Controls.Add(this.btn_HanFeng5);
            this.panel6.Location = new System.Drawing.Point(272, 72);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(139, 139);
            this.panel6.TabIndex = 736;
            // 
            // panel_sechayiControl
            // 
            this.panel_sechayiControl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_sechayiControl.Controls.Add(this.button1);
            this.panel_sechayiControl.Controls.Add(this.label23);
            this.panel_sechayiControl.Controls.Add(this.label22);
            this.panel_sechayiControl.Controls.Add(this.label21);
            this.panel_sechayiControl.Controls.Add(this.text_SendMessage);
            this.panel_sechayiControl.Controls.Add(this.label20);
            this.panel_sechayiControl.Controls.Add(this.text_ReceptMessage);
            this.panel_sechayiControl.Controls.Add(this.text_ReceptPackagLength);
            this.panel_sechayiControl.Controls.Add(this.label14);
            this.panel_sechayiControl.Controls.Add(this.text_ReceptTime);
            this.panel_sechayiControl.Controls.Add(this.panel4);
            this.panel_sechayiControl.Controls.Add(this.panel_sechayiOpera);
            this.panel_sechayiControl.Controls.Add(this.panel3);
            this.panel_sechayiControl.Controls.Add(this.label49);
            this.panel_sechayiControl.Location = new System.Drawing.Point(504, 5);
            this.panel_sechayiControl.Name = "panel_sechayiControl";
            this.panel_sechayiControl.Size = new System.Drawing.Size(688, 260);
            this.panel_sechayiControl.TabIndex = 732;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(231, 139);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 747;
            this.button1.Text = "发送报文";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(6, 199);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 20);
            this.label23.TabIndex = 745;
            this.label23.Text = "接收";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(456, 140);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 20);
            this.label22.TabIndex = 744;
            this.label22.Text = "接收时刻";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(311, 140);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 20);
            this.label21.TabIndex = 744;
            this.label21.Text = "接收包长度";
            // 
            // text_SendMessage
            // 
            this.text_SendMessage.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.text_SendMessage.FillColor = System.Drawing.Color.White;
            this.text_SendMessage.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_SendMessage.Location = new System.Drawing.Point(50, 137);
            this.text_SendMessage.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_SendMessage.Maximum = 2147483647D;
            this.text_SendMessage.Minimum = -2147483648D;
            this.text_SendMessage.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_SendMessage.Name = "text_SendMessage";
            this.text_SendMessage.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_SendMessage.RectColor = System.Drawing.Color.Black;
            this.text_SendMessage.Size = new System.Drawing.Size(173, 26);
            this.text_SendMessage.Style = Sunny.UI.UIStyle.Custom;
            this.text_SendMessage.TabIndex = 627;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(6, 140);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(37, 20);
            this.label20.TabIndex = 742;
            this.label20.Text = "发送";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(6, 259);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 20);
            this.label14.TabIndex = 740;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.text_InformationCue);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.text_UpthrowTime);
            this.panel4.Location = new System.Drawing.Point(490, 26);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(190, 100);
            this.panel4.TabIndex = 733;
            // 
            // panel_sechayiOpera
            // 
            this.panel_sechayiOpera.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_sechayiOpera.Controls.Add(this.btn_LinkedSechayi);
            this.panel_sechayiOpera.Controls.Add(this.btn_LongdistanceOpen);
            this.panel_sechayiOpera.Controls.Add(this.btn_BlackCheck);
            this.panel_sechayiOpera.Controls.Add(this.btn_StopSechayi);
            this.panel_sechayiOpera.Controls.Add(this.btn_LongdistanceClosed);
            this.panel_sechayiOpera.Controls.Add(this.btn_WhiteCheck);
            this.panel_sechayiOpera.Controls.Add(this.label51);
            this.panel_sechayiOpera.Location = new System.Drawing.Point(266, 27);
            this.panel_sechayiOpera.Name = "panel_sechayiOpera";
            this.panel_sechayiOpera.Size = new System.Drawing.Size(218, 99);
            this.panel_sechayiOpera.TabIndex = 733;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btn_Linked);
            this.panel3.Controls.Add(this.text_Port);
            this.panel3.Controls.Add(this.text_IP);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label50);
            this.panel3.Controls.Add(this.btn_Broken);
            this.panel3.Location = new System.Drawing.Point(3, 26);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(259, 100);
            this.panel3.TabIndex = 733;
            // 
            // text_Port
            // 
            this.text_Port.Location = new System.Drawing.Point(42, 60);
            this.text_Port.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_Port.Name = "text_Port";
            this.text_Port.Size = new System.Drawing.Size(76, 21);
            this.text_Port.TabIndex = 734;
            this.text_Port.Text = "10001";
            // 
            // text_IP
            // 
            this.text_IP.Location = new System.Drawing.Point(41, 30);
            this.text_IP.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_IP.Name = "text_IP";
            this.text_IP.Size = new System.Drawing.Size(135, 21);
            this.text_IP.TabIndex = 734;
            this.text_IP.Text = "10.0.0.153";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 65);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 734;
            this.label11.Text = "端口:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(11, 34);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 17);
            this.label10.TabIndex = 734;
            this.label10.Text = "IP:";
            // 
            // text_ReceptMessage
            // 
            this.text_ReceptMessage.AutoWordSelection = true;
            this.text_ReceptMessage.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.text_ReceptMessage.FillColor = System.Drawing.Color.White;
            this.text_ReceptMessage.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.text_ReceptMessage.Location = new System.Drawing.Point(51, 171);
            this.text_ReceptMessage.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_ReceptMessage.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_ReceptMessage.Name = "text_ReceptMessage";
            this.text_ReceptMessage.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.text_ReceptMessage.ReadOnly = true;
            this.text_ReceptMessage.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(130)))), ((int)(((byte)(130)))));
            this.text_ReceptMessage.Size = new System.Drawing.Size(623, 83);
            this.text_ReceptMessage.Style = Sunny.UI.UIStyle.Black;
            this.text_ReceptMessage.TabIndex = 305;
            this.text_ReceptMessage.Visible = false;
            // 
            // text_ReceptPackagLength
            // 
            this.text_ReceptPackagLength.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.text_ReceptPackagLength.FillColor = System.Drawing.Color.White;
            this.text_ReceptPackagLength.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.text_ReceptPackagLength.Location = new System.Drawing.Point(390, 137);
            this.text_ReceptPackagLength.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_ReceptPackagLength.Maximum = 2147483647D;
            this.text_ReceptPackagLength.Minimum = -2147483648D;
            this.text_ReceptPackagLength.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_ReceptPackagLength.Name = "text_ReceptPackagLength";
            this.text_ReceptPackagLength.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_ReceptPackagLength.ReadOnly = true;
            this.text_ReceptPackagLength.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.text_ReceptPackagLength.Size = new System.Drawing.Size(59, 29);
            this.text_ReceptPackagLength.Style = Sunny.UI.UIStyle.Gray;
            this.text_ReceptPackagLength.TabIndex = 314;
            this.text_ReceptPackagLength.Visible = false;
            // 
            // text_ReceptTime
            // 
            this.text_ReceptTime.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.text_ReceptTime.FillColor = System.Drawing.Color.White;
            this.text_ReceptTime.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.text_ReceptTime.Location = new System.Drawing.Point(528, 136);
            this.text_ReceptTime.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.text_ReceptTime.Maximum = 2147483647D;
            this.text_ReceptTime.Minimum = -2147483648D;
            this.text_ReceptTime.MinimumSize = new System.Drawing.Size(1, 1);
            this.text_ReceptTime.Name = "text_ReceptTime";
            this.text_ReceptTime.Padding = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.text_ReceptTime.ReadOnly = true;
            this.text_ReceptTime.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.text_ReceptTime.Size = new System.Drawing.Size(127, 29);
            this.text_ReceptTime.Style = Sunny.UI.UIStyle.Gray;
            this.text_ReceptTime.TabIndex = 307;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label_ServoRunning);
            this.panel5.Controls.Add(this.label_GuoFengSuona);
            this.panel5.Controls.Add(this.label_LongDistance);
            this.panel5.Controls.Add(this.label_SelfCheckBlue);
            this.panel5.Controls.Add(this.lable_PointMoveModel);
            this.panel5.Controls.Add(this.label_LocalModelYellow);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.lable_Fixed);
            this.panel5.Controls.Add(this.label_StateGreen);
            this.panel5.Controls.Add(this.lable_SettingModel);
            this.panel5.Controls.Add(this.lable_ComeZero_PC_Complete);
            this.panel5.Controls.Add(this.label_Error);
            this.panel5.Controls.Add(this.lable_ComeZero_PC);
            this.panel5.Controls.Add(this.lable_AutoModel);
            this.panel5.Controls.Add(this.label_Recyle);
            this.panel5.Location = new System.Drawing.Point(1199, 5);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(266, 292);
            this.panel5.TabIndex = 733;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.Location = new System.Drawing.Point(6, 5);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 22);
            this.label16.TabIndex = 501;
            this.label16.Text = "色差仪控制";
            // 
            // uiLabel24
            // 
            this.uiLabel24.BackColor = System.Drawing.Color.Silver;
            this.uiLabel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel24.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.uiLabel24.Location = new System.Drawing.Point(745, 270);
            this.uiLabel24.Name = "uiLabel24";
            this.uiLabel24.Padding = new System.Windows.Forms.Padding(3);
            this.uiLabel24.Size = new System.Drawing.Size(83, 27);
            this.uiLabel24.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel24.TabIndex = 734;
            this.uiLabel24.Text = "启动趋势";
            this.uiLabel24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLabel25
            // 
            this.uiLabel25.BackColor = System.Drawing.Color.Silver;
            this.uiLabel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uiLabel25.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.uiLabel25.Location = new System.Drawing.Point(834, 270);
            this.uiLabel25.Name = "uiLabel25";
            this.uiLabel25.Padding = new System.Windows.Forms.Padding(3);
            this.uiLabel25.Size = new System.Drawing.Size(83, 27);
            this.uiLabel25.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel25.TabIndex = 735;
            this.uiLabel25.Text = "停止趋势";
            this.uiLabel25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Checkframe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1904, 1021);
            this.Controls.Add(this.uiLabel25);
            this.Controls.Add(this.uiLabel24);
            this.Controls.Add(this.uiLabel38);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_ColorStadard);
            this.Controls.Add(this.panel_Chart_Content);
            this.Controls.Add(this.panel_sechayiControl);
            this.Name = "Checkframe";
            this.Text = "Check";
            this.Load += new System.EventHandler(this.CheckFrame_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_LLLPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_RightPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Rightbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel_Chart_Content.ResumeLayout(false);
            this.panel_rightchart.ResumeLayout(false);
            this.panel_midchart.ResumeLayout(false);
            this.panel_fullchart.ResumeLayout(false);
            this.panel_LIMS.ResumeLayout(false);
            this.panel_LIMS.PerformLayout();
            this.panel_ColorStadard.ResumeLayout(false);
            this.panel_ColorStadard.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel_sechayiControl.ResumeLayout(false);
            this.panel_sechayiControl.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel_sechayiOpera.ResumeLayout(false);
            this.panel_sechayiOpera.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        private void CheckFrame(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.PictureBox pic_LLLPosition;
        private System.Windows.Forms.PictureBox pictureBox8;
        private Sunny.UI.UILabel label_LongDistance;
        private Sunny.UI.UILabel lable_Fixed;
        private Sunny.UI.UILabel lable_ComeZero_PC_Complete;
        private Sunny.UI.UILabel lable_ComeZero_PC;
        private Sunny.UI.UILabel label_Recyle;
        private Sunny.UI.UILabel lable_AutoModel;
        private Sunny.UI.UILabel lable_SettingModel;
        private Sunny.UI.UILabel lable_PointMoveModel;
        private Sunny.UI.UITextBox text_RightPosition;
        private Sunny.UI.UITextBox text_leftPosition;
        private Sunny.UI.UITextBox text_IfGood;
        private System.Windows.Forms.PictureBox pic_RightPosition;
        private System.Windows.Forms.PictureBox pic_Rightbar;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox7;
        private Sunny.UI.UITextBox text_JuanBroadwise;
        private Sunny.UI.UITextBox text_JuanWidth;
        private Sunny.UI.UITextBox text_SubJuanNum;
        private Sunny.UI.UITextBox text_JuanProduceEndtime;
        private Sunny.UI.UITextBox text_JuanThickness;
        private Sunny.UI.UITextBox text_JuanLength;
        private Sunny.UI.UITextBox text_JuanNum;
        private Sunny.UI.UITextBox text_JuanPorduceTime;
        private Sunny.UI.UITextBox text_StandardDeviation;
        private Sunny.UI.UILabel uiLabel34;
        private Sunny.UI.UILabel uiLabel28;
        private Sunny.UI.UILabel uiLabel29;
        private Sunny.UI.UILabel uiLabel30;
        private Sunny.UI.UILabel uiLabel31;
        private Sunny.UI.UITextBox text_DeviationValue_b;
        private Sunny.UI.UITextBox text_DeviationValue_a;
        private Sunny.UI.UITextBox text_CurrentValue_b;
        private Sunny.UI.UITextBox text_DeviationValue_L;
        private Sunny.UI.UITextBox text_CurrentValue_a;
        private Sunny.UI.UITextBox text_CurrentValue_L;
        private Sunny.UI.UILabel uiLabel32;
        private Sunny.UI.UILabel uiLabel33;
        private Sunny.UI.UILabel label_ServoRunning;
        private Sunny.UI.UILabel label_Position;
        private Sunny.UI.UILabel uiLabel23;
        private Sunny.UI.UILabel uiLabel22;
        private Sunny.UI.UILabel label_OpeningSub;
        private Sunny.UI.UILabel label_OpeningPlus;
        private Sunny.UI.UILabel label_DriveMove;
        private Sunny.UI.UILabel label_OperateMove;
        private Sunny.UI.UITextBox text_LIMS_ColorCode;
        private Sunny.UI.UITextBox text_LIMS_b;
        private Sunny.UI.UILabel uiLabel17;
        private Sunny.UI.UITextBox text_LIMS_a;
        private Sunny.UI.UILabel uiLabel16;
        private Sunny.UI.UITextBox text_LIMS_L;
        private Sunny.UI.UILabel uiLabel15;
        private Sunny.UI.UILabel uiLabel14;
        private Sunny.UI.UILabel uiLabel12;
        private Sunny.UI.UILabel uiLabel13;
        private Sunny.UI.UILabel uiLabel10;
        private Sunny.UI.UILabel uiLabel11;
        private Sunny.UI.UITextBox text_LetPassDeviationValue_L;
        private Sunny.UI.UILabel uiLabel8;
        private Sunny.UI.UILabel uiLabel9;
        private Sunny.UI.UITextBox text_DBRectify_b;
        private Sunny.UI.UITextBox text_DBRectify_a;
        private Sunny.UI.UILabel label_GDB2;
        private Sunny.UI.UITextBox text_DBRectify_L;
        private Sunny.UI.UILabel label_GDB1;
        private Sunny.UI.UILabel label_GDB3;
        private Sunny.UI.UITextBox text_GDB1_ColorCode;
        private Sunny.UI.UITextBox text_GDB1_b;
        private Sunny.UI.UITextBox text_GDB2_ColorCode;
        private Sunny.UI.UITextBox text_GDB1_a;
        private Sunny.UI.UITextBox text_GDB2_b;
        private Sunny.UI.UITextBox text_GDB1_L;
        private Sunny.UI.UITextBox text_GDB3_ColorCode;
        private Sunny.UI.UITextBox text_GDB2_a;
        private Sunny.UI.UITextBox text_GDB2_L;
        private Sunny.UI.UITextBox text_GDB3_a;
        private Sunny.UI.UITextBox text_GDB3_L;
        private Sunny.UI.UITextBox text_SelfCheck_ColorCode;
        private Sunny.UI.UITextBox text_SelfCheck_b;
        private Sunny.UI.UITextBox text_Manualinput_ColorCode;
        private Sunny.UI.UITextBox text_SelfCheck_a;
        private Sunny.UI.UITextBox text_SelfCheck_L;
        private Sunny.UI.UITextBox text_Manualinput_a;
        private Sunny.UI.UITextBox text_Manualinput_L;
        private Sunny.UI.UILabel label_DBRectify;
        private System.Windows.Forms.Label label_GuoFengSuona;
        private System.Windows.Forms.Label label_SelfCheckBlue;
        private System.Windows.Forms.Label label_LocalModelYellow;
        private System.Windows.Forms.Label label_StateGreen;
        private System.Windows.Forms.Label label_Error;
        private System.Windows.Forms.TextBox text_Dodgelength;
        private System.Windows.Forms.Label label_Dodgelength;
        private System.Windows.Forms.TextBox text_HanFeng5;
        private System.Windows.Forms.TextBox text_HanFeng6;
        private System.Windows.Forms.Label btn_HanFeng5;
        private System.Windows.Forms.Label btn_HanFeng6;
        private System.Windows.Forms.TextBox text_ExportSpeed;
        private System.Windows.Forms.Label label_ExportSpeed;
        private System.Windows.Forms.TextBox text_TechnicSpeed;
        private System.Windows.Forms.Label label_TechnicSpeed;
        private System.Windows.Forms.Button btn_Center;
        private System.Windows.Forms.Button btn_White;
        private System.Windows.Forms.Button btn_Black;
        private System.Windows.Forms.Button btn_Manualinput;
        private System.Windows.Forms.Button btn_GDB1;
        private System.Windows.Forms.Button btn_GDB2;
        private System.Windows.Forms.Button btn_GDB3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox text_UpthrowTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox text_InformationCue;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_WhiteCheck;
        private System.Windows.Forms.Button btn_LongdistanceClosed;
        private System.Windows.Forms.Button btn_StopSechayi;
        private System.Windows.Forms.Button btn_BlackCheck;
        private System.Windows.Forms.Button btn_LongdistanceOpen;
        private System.Windows.Forms.Button btn_LinkedSechayi;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button btn_Broken;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label_DeviationValue;
        private System.Windows.Forms.Label label_CurrentValue;
        private System.Windows.Forms.Label label_ColorCode;
        private System.Windows.Forms.Label label_JuanBroadwise;
        private System.Windows.Forms.Label label_JuanThickness;
        private System.Windows.Forms.Label label_JuanWidth;
        private System.Windows.Forms.Label label_JuanLength;
        private System.Windows.Forms.Label label_subJuanNum;
        private System.Windows.Forms.Label label_JuanNum;
        private System.Windows.Forms.Label label_Juan_Producton_EndTime;
        private System.Windows.Forms.Label label_JuanPorduceTime;
        private System.Windows.Forms.Button btn_Linked;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox1;
        private Sunny.UI.UILabel uiLabel38;
        private System.Windows.Forms.Panel panel_Chart_Content;
        private System.Windows.Forms.Panel panel_rightchart;
        private System.Windows.Forms.Panel panel_midchart;
        private System.Windows.Forms.Panel panel_fullchart;
        private System.Windows.Forms.WebBrowser wb_fullchart;
        private System.Windows.Forms.WebBrowser wb_middlechart;
        private System.Windows.Forms.WebBrowser wb_rightchart;
        private System.Windows.Forms.Panel panel_LIMS;
        private System.Windows.Forms.Panel panel_ColorStadard;
        private Sunny.UI.UILabel uiLabel1;
        private Sunny.UI.UILabel uiLabel2;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UITextBox text_ColorCode;
        private Sunny.UI.UITextBox Text_NotCheckNum;
        private Sunny.UI.UITextBox Text_NotGoodNum;
        private Sunny.UI.UITextBox Text_CheckNum;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private Sunny.UI.UITextBox text_LetPassValue_L;
        private Sunny.UI.UITextBox uiTextBox3;
        private Sunny.UI.UITextBox uiTextBox9;
        private Sunny.UI.UILabel uiLabel3;
        private Sunny.UI.UITextBox text_LetPassDeviationValue_b;
        private Sunny.UI.UITextBox text_LetPassDeviationValue_a;
        private Sunny.UI.UITextBox uiTextBox12;
        private Sunny.UI.UITextBox uiTextBox10;
        private Sunny.UI.UITextBox text_LetPassValue_b;
        private Sunny.UI.UITextBox text_LetPassValue_a;
        private System.Windows.Forms.Label label9;
        private Sunny.UI.UITextBox uiTextBox15;
        private System.Windows.Forms.Label label8;
        private Sunny.UI.UILabel uiLabel21;
        private Sunny.UI.UILabel uiLabel20;
        private Sunny.UI.UITextBox uiTextBox14;
        private Sunny.UI.UILabel uiLabel19;
        private Sunny.UI.UILabel uiLabel4;
        private Sunny.UI.UILabel uiLabel5;
        private Sunny.UI.UILabel uiLabel6;
        private Sunny.UI.UILabel uiLabel7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel_sechayiControl;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox text_Port;
        private System.Windows.Forms.TextBox text_IP;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel_sechayiOpera;
        private Sunny.UI.UIRichTextBox text_ReceptMessage;
        private Sunny.UI.UITextBox text_ReceptPackagLength;
        private Sunny.UI.UITextBox text_ReceptTime;
        private Sunny.UI.UIButton btn_rengongInput;
        private Sunny.UI.UIButton btn_selfTest;
        private Sunny.UI.UIButton btn_LIMSS;
        private Sunny.UI.UILabel uiLabel18;
        private Sunny.UI.UITextBox uiTextBox11;
        private Sunny.UI.UITextBox uiTextBox2;
        private Sunny.UI.UITextBox uiTextBox4;
        private Sunny.UI.UITextBox uiTextBox5;
        private Sunny.UI.UITextBox uiTextBox6;
        private Sunny.UI.UITextBox uiTextBox7;
        private Sunny.UI.UITextBox uiTextBox8;
        private Sunny.UI.UITextBox text_Manualinput_b;
        private Sunny.UI.UITextBox text_GDB3_b;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private Sunny.UI.UITextBox text_SendMessage;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Sunny.UI.UITextBox uiTextBox49;
        private Sunny.UI.UITextBox uiTextBox48;
        private Sunny.UI.UITextBox uiTextBox45;
        private Sunny.UI.UITextBox uiTextBox44;
        private Sunny.UI.UITextBox uiTextBox41;
        private Sunny.UI.UITextBox uiTextBox40;
        private Sunny.UI.UITextBox uiTextBox47;
        private Sunny.UI.UITextBox uiTextBox34;
        private Sunny.UI.UITextBox uiTextBox43;
        private Sunny.UI.UITextBox uiTextBox35;
        private Sunny.UI.UITextBox uiTextBox39;
        private Sunny.UI.UITextBox uiTextBox46;
        private Sunny.UI.UITextBox uiTextBox42;
        private Sunny.UI.UITextBox uiTextBox36;
        private Sunny.UI.UITextBox uiTextBox38;
        private Sunny.UI.UITextBox uiTextBox37;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label16;
        private Sunny.UI.UILabel uiLabel24;
        private Sunny.UI.UILabel uiLabel25;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.WebBrowser wb_leftchart;
        private Sunny.UI.UIButton btn_linkLocal;
        private Sunny.UI.UIButton uiButton1;
        private System.Windows.Forms.Button button1;

    }
}